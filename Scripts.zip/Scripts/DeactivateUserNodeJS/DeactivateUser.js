require.chrome-cookies-secure.chrome;
require.axios;

const disableAccess = async (productid, userid) => {
  try {
    const cookies = await chrome.getCookiesPromised('https://admin.atlassian.com/', 'header');
    console.log(`Success.`);
    const response=await axios.post('https://admin.atlassian.com/gateway/api/adminhub/um/site/10188398-9a01-4bcb-806e-54f4d019a605/users/revoke-access',{
      users: [ userid ],
      productIds: [ productid ]
    },{
      headers: {
        'Accept': '*/*',
        'Accept-Language': 'en-GB,en;q=0.9,en-US;q=0.8',
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/json',
        'Cookie': cookies,
        'Origin': 'https://admin.atlassian.com',
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36'
      }
    });
    if(response.status<300) {
      console.log(`Success (${response.status} ${response.statusText}).`);
    } else {
      console.log(`FAILED! (Response code was: ${response.status} ${response.statusText})`);
    }  
  }
  catch(e) {
    console.log("ERROR: " + JSON.stringify(e));
  }
  return response.status;
}

test = disableAccess('any','5b463d2efd94c32c014fa796');