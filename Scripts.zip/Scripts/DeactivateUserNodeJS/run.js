var test23 = require('./DeactivateUser');

test = test23.disableAccess('any','5b463d2efd94c32c014fa796');

test
    