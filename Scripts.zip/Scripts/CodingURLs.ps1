
$url = '(text~%22PRED-39807*%22%20OR%20KEY%3D%22PRED-39807%22)%20AND%20(cf%5B10020%5D%20IS%20EMPTY%20OR%20cf%5B10020%5D%20NOT%20IN%20(1906%2C1907%2C1908%2C1909%2C1910%2C1911))%20AND%20hierarchyLevel%20in%20(0%2C%201)%20AND%20statusCategory%20!%3D%20done%20AND%20filter%20in%20(14951)%20AND%20issuetype%20not%20in%20subtaskIssueTypes()%20%20ORDER%20BY%20cf%5B10019%5D'

#write-host ([System.Net.WebUtility]::HtmlDecode($url))
#write-host ([System.Net.WebUtility]::HtmlEncode($url))
write-host ([uri]::UnescapeDataString($url))
#write-host ([uri]::EscapeUriString($url))
