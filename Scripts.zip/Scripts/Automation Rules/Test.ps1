$cloudID = "c28f6376-7be4-4e21-9b3e-a2d9676f3039"
$projectID = "10161"
$customerName = "AIG"
$productName = "Bridge Specialty Suite"
$initiativeKey = "INSU-1094"

Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}
$url = "https://api.atlassian.com/automation/public/jira/$cloudID/rest/v1/rule"

$body = @{
    "rule" = @{
        "name" = "Set Project Defaults"
        "state" = "ENABLED"
        "description" = ""
        "canOtherRuleTrigger" = $false
        "notifyOnError" = "FIRSTERROR"
        "authorAccountId" = "60f6fc2bd5c9290069653461"
        "actor" = @{
            "type" = "ACCOUNT_ID"
            "actor" = "557058:f58131cb-b67d-43c7-b30d-6b58d40bd077"
        }
        "trigger" = @{
            "component" = "TRIGGER"
            "schemaVersion" = 1
            "type" = "jira.issue.event.trigger:created"
            "value" = @{
                "eventKey" = "jira:issue_created"
                "issueEvent" = "issue_created"
                "eventFilters" = @(
                    "ari:cloud:jira:"+$cloudID+":project/$projectID"
                )
            }
            "connectionId" = $null
            "conditions" = @()
        }
        "components" = @(
            @{
                "component" = "ACTION"
                "schemaVersion" = 12
                "type" = "jira.issue.edit"
                "value" = @{
                    "operations" = @(
                        @{
                            "field" = @{
                                "type" = "NAME"
                                "value" = "Allocation Category"
                            }
                            "fieldType" = "com.atlassian.jira.plugin.system.customfieldtypes:select"
                            "type" = "SET"
                            "value" = @{
                                "type" = "NAME"
                                "value" = "Customer Driven – 1X (Contracted / SOW)"
                            }
                        }
                        @{
                            "field" = @{
                                "type" = "NAME"
                                "value" = "Initiated by Customer"
                            }
                            "fieldType" = "com.atlassian.jira.plugin.system.customfieldtypes:select"
                            "type" = "SET"
                            "value" = @{
                                "type" = "NAME"
                                "value" = $customerName
                            }
                        }
                        @{
                            "field" = @{
                                "type" = "NAME"
                                "value" = "Product"
                            }
                            "fieldType" = "com.atlassian.jira.plugin.system.customfieldtypes:select"
                            "type" = "SET"
                            "value" = @{
                                "type" = "NAME"
                                "value" = $productName
                            }
                        }
                        @{
                            "field" = @{
                                "type" = "ID"
                                "value" = "priority"
                            }
                            "fieldType" = "priority"
                            "type" = "SET"
                            "value" = @{
                                "type" = "ID"
                                "value" = "10002"
                            }
                        }
                    )
                    "advancedFields" = $null
                    "sendNotifications" = $true
                }
                "connectionId" = $null
                "conditions" = @()
                "parentId" = $null
                "conditionParentId" = $null
                "children" = @()
            }
            @{
                "component" = "CONDITION"
                "schemaVersion" = 3
                "type" = "jira.issue.condition"
                "value" = @{
                    "selectedField" = @{
                        "type" = "ID"
                        "value" = "issuetype"
                    }
                    "selectedFieldType" = "issuetype"
                    "comparison" = "ONE_OF"
                    "compareValue" = @{
                        "type" = "ID"
                        "modifier" = $null
                        "value" = "[`"10000`",`"10156`",`"10012`"]"
                        "multiValue" = $true
                        "source" = $null
                    }
                }
                "connectionId" = $null
                "conditions" = @()
                "parentId" = $null
                "conditionParentId" = $null
                "children" = @()
            }
            @{
                "component" = "ACTION"
                "schemaVersion" = 12
                "type" = "jira.issue.edit"
                "value" = @{
                    "operations" = @(
                        @{
                            "field" = @{
                                "type" = "ID"
                                "value" = "parent"
                            }
                            "fieldType" = "parent"
                            "type" = "SET"
                            "value" = @{
                                "type" = "FREE"
                                "value" = $initiativeKey
                            }
                        }
                    )
                    "advancedFields" = $null
                    "sendNotifications" = $true
                }
                "connectionId" = $null
                "conditions" = @()
                "parentId" = $null
                "conditionParentId" = $null
                "children" = @()
            }
        )
        "ruleScopeARIs" = @(
            "ari:cloud:jira:"+$cloudID+":project/$projectID"
        )
        "labels" = @()
        "writeAccessType" = "UNRESTRICTED"
        "collaborators" = @()
    }
    "connections" = @()
} | ConvertTo-Json -Depth 20 -EscapeHandling EscapeNonAscii

$responce = Invoke-RestMethod -Method POST -Uri $url -Headers $headers -Body $body
$responce