Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$headers = @{
        'Authorization' = "Basic $cred"
        'content-type' = 'application/json'
    }

function Copy-FieldValues {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey,
        [Parameter()]
        [String]$sourceField,
        [Parameter()]
        [System.Object]$sourceFieldValue,
        [Parameter(Mandatory=$true)]
        [String]$targetField
    
    )
    
    $body = @{
        "fields" = @{
            $targetField = @{
                "content" = 
                    @(
                        @{
                            "content" = @($sourceFieldValue)
                            "type" = "paragraph"
                        }
                    )
                    "type" = "doc"
                    "version" = 1
            }
        }
    } | ConvertTo-Json -Depth 100

    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue/"+$issueKey
    
    try {
        Invoke-RestMethod -Method 'put' -Uri $url -Headers $headers -Body $body
    }
    catch {
        return $issueKey
    }
    
}


$nextPage = ""
$failedIssues = @()
do {
    if ($nextPage){
        $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/search/jql?jql=`"Public Resolution Notes[Paragraph]`" IS NOT EMPTY and type NOT IN subTaskIssueTypes() and category NOT IN (Internal, `"Prof Services`")&fields=customfield_10060,customfield_10600&nextPageToken=$nextPage"
    }
    else {
        $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/search/jql?jql=`"Public Resolution Notes[Paragraph]`" IS NOT EMPTY and type NOT IN subTaskIssueTypes() and category NOT IN (Internal, `"Prof Services`")&fields=customfield_10060,customfield_10600"
    }
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
    foreach ($issue in $responce.issues){
        if (!$issue.fields.customfield_10600){
            $failedIssues += Copy-FieldValues -issueKey $issue.key -sourceField "customfield_10060" -targetField "customfield_10600" -sourceFieldValue $issue.fields.customfield_10060.content.content
        }
        
        $nextPage = $responce.nextPageToken
    }
    
    } while ($nextPage)

$failedIssues | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\failedIssues.csv" -Force