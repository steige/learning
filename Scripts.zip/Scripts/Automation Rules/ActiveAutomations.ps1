$automations = Get-Content "C:\Users\Micah.Harley\Downloads\automation-rules-202507141638.json" | ConvertFrom-Json

$rulesOut = @()
foreach ($rule in $automations.rules){
    if ($rule.state -eq "ENABLED"){
        $rulesOut += $rule
    }
}

$connections = @()
foreach ($connection in $automations.connections){
    $connections += $connection
}

$outfile = @{
    "cloud" = $true
    "rules" = $rulesOut
    "connections" = $connections
}

$json = $outfile | ConvertTo-Json -Depth 20

Set-Content -Path "C:\Users\Micah.Harley\Downloads\automation-rules-clean.json" -Value $json