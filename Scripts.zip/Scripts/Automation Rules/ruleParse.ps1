$rules = Get-Content '.\Automation Rules\rules.json' | ConvertFrom-Json

$csvOut = @()

foreach ($rule in $rules.rules){
    # Check triggers for fields
    foreach ($field in $rule.trigger.value.fields){
        $csvOut += @{
            "ruleName" = $rule.name
            "state" = $rule.state
            "fieldName" = if($field.value){$field.value}else{""}
            "valueType" = if($field.type){$field.type}else{""}
            "From" = if($rule.trigger.component){$rule.trigger.component}else{""}
        }
    }

    foreach ($component in $rule.components){
        foreach ($field in $component.fields){
            $csvOut += @{
                "ruleName" = $rule.name
                "state" = $rule.state
                "fieldName" = if($field.value){$field.value}else{""}
                "valueType" = if($field.type){$field.type}else{""}
                "From" = if($rule.component.component){$rule.component.component}else{""}
            }
        }

        if ($component.value.selectedField){
            $csvOut += @{
                "ruleName" = $rule.name
                "state" = $rule.state
                "fieldName" = if($component.value.selectedField.value){$component.value.selectedField.value}else{""}
                "valueType" = if($component.value.selectedField.type){$component.value.selectedField.type}else{""}
                "From" = if($rule.component.component){$rule.component.component}else{""}
            }
        }

        foreach ($childMain in $component.children){
            $child = $childMain

            do {
                #assumes action, not condition
                foreach ($field in $child.fields){
                    $csvOut += @{
                        "ruleName" = $rule.name
                        "state" = $rule.state
                        "fieldName" = if($field.value){$field.value}else{""}
                        "valueType" = if($field.type){$field.type}else{""}
                        "From" = if($child.component){$child.component}else{""}
                    }
                }

                foreach ($field in $child.value.operations){
                    $csvOut += @{
                        "ruleName" = $rule.name
                        "state" = $rule.state
                        "fieldName" = if($field.field.value){$field.field.value}else{""}
                        "valueType" = if($field.field.type){$field.field.type}else{""}
                        "From" = if($child.component){$child.component}else{""}
                    }
                }

                #assumes condition
                foreach ($condition in $child.conditions){
                    $csvOut += @{
                        "ruleName" = if($rule.name){$rule.name}else{""}
                        "state" = if($rule.state){$rule.state}else{""}
                        "fieldName" = if($condition.value.selectedField.value){$condition.value.selectedField.value}else{""}
                        "valueType" = if($condition.value.selectedField.type){$condition.value.selectedField.type}else{""}
                        "From" = if($condition.component){$condition.component}else{""}
                    }
                }

                if ($($child.children).count -eq $($child.conditions).count -or $($child.children).count -eq 0 ){
                    $continue = $false
                }
                else {
                    $continue = $true
                    $child = $child.children
                }
                
            } while ($continue)
        }
    }
}

$csvOut | Export-Csv -Path ".\Automation Rules\fieldsUsedInRules.csv" -Force 