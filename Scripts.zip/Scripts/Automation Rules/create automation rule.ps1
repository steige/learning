$projectID = "10576"
$product = "Sure Premium Audit"
$customer = "Alabama Trucking Assoc. WCF"
$initiative = "INSU-31068"
$bridge = "INSU-31097"

Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

$payload = @{
    "rule" = @{
        "name" = "Set Project Defaults"
        "state" = "Enabled"
        "description" = ""
        "authorAccountId" = "60f6fc2bd5c9290069653461"
        "actor" = @{
            "type" = "ACCOUNT_ID"
            "value" = "557058:f58131cb-b67d-43c7-b30d-6b58d40bd077"
        }
        
        "trigger" = @{
            "component" = "TRIGGER"
            "parentId" = $null
            "conditionParentId" = $null
            "schemaVersion" = 1
            "type" = "jira.issue.event.trigger:created"
            "value" = @{
                "eventKey" = "jira:issue_created"
                "issueEvent" = "issue_created"
                "eventFilters" = @(
                    "ari:cloud:jira:10188398-9a01-4bcb-806e-54f4d019a605:project/$projectID"
                )
            }
            "children" = @()
            "conditions" = @()
            "connectionId" = $null
        }
        
        "canOtherRuleTrigger" = $false
        "notifyOnError" = "FIRSTERROR"
        "labels" = @()
        "ruleScopeARIs" = @(
            "ari:cloud:jira:c28f6376-7be4-4e21-9b3e-a2d9676f3039:project/$projectID"
            
        )
        
        "writeAccessType" = "UNRESTRICTED"
        "collaborators" = @()
    }
}

$body = $payload | ConvertTo-Json -Depth 20

$url = "https://api.atlassian.com/automation/public/jira/c28f6376-7be4-4e21-9b3e-a2d9676f3039/rest/v1/rule"

Invoke-RestMethod -Method POST -Uri $url -Headers $headers -Body $body