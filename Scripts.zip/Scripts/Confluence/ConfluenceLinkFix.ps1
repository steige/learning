Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'COConfluence'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$spaceKey = "SCE"
$url = "https://cowiki-corp.hostedinsurance.com/rest/api/content?spaceKey=$spaceKey&type=page&limit=1000"
    
$headers = @{
    'Authorization' = "Basic $cred"
}

$responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

$csvOut = @()
foreach ($page in $responce.results){
    $csvOut += [ordered]@{
        "title" = $page.title
        "contentid" = $page.id
        "spacekey" = $spaceKey
    }
}

$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\InstecADO\$spacekey results.csv"