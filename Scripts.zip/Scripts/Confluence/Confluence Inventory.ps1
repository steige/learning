Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
}

function Get-AllSpaces {
    param ()

    $url = "https://insurity.atlassian.net/wiki/api/v2/spaces?status=current&type=personal"

    $returnObject = @()
    $continue = $true

    while ($continue) {
        $results = Invoke-RestMethod -Method Get -Uri $url -Headers $headers
        $returnObject += $results.results

        if ($results._links.next) {
            $url = "https://insurity.atlassian.net$($results._links.next)"
        }
        else {
            $continue = $false
        }
    }

    return $returnObject    
}
function Get-LastPageUpdate {
    param (
        [Parameter(Mandatory=$true)]
        [string]$spaceID
    )
    
    $url = "https://insurity.atlassian.net/wiki/api/v2/pages?space-id=$spaceID&sort=-modified-date"

    $results = Invoke-RestMethod -Method Get -Uri $url -Headers $headers

    return $results.results[0]
}
function Get-SpaceAdmin {
    param (
        [Parameter(Mandatory=$true)]
        [string]$spaceID
    )
    
    $url = "https://insurity.atlassian.net/wiki/api/v2/spaces/$spaceID/permissions"

    $permissions = @()
    $continue = $true

    while ($continue) {
        $results = Invoke-RestMethod -Method Get -Uri $url -Headers $headers
        $permissions += $results.results

        if ($results._links.next) {
            $url = "https://insurity.atlassian.net$($results._links.next)"
        }
        else {
            $continue = $false
        }
    }

    $spaceAdmin = @()
    foreach($permission in $permissions){
        if($permission.operation.key -eq "administer" -and $permission.principal.type -eq "user"`
         -and $permission.principal.id -ne "557058:9ab63286-11ed-497d-8147-88b76e6c8a56" `
         -and $permission.principal.id -ne "6035864ce2020c0070b5285b" `
         -and $permission.principal.id -ne "5b70c8b80fd0ac05d389f5e9" `
         -and $permission.principal.id -ne "61251b7f4f2923006934ce76" `
         -and $permission.principal.id -ne "557058:8de19811-27e5-461f-bd19-b63b555aea6d" `
         -and $permission.principal.id -ne "5b868d24b8624857f09f211d" `
         -and $permission.principal.id -ne "63d7ca32c3eb74ad8e94c571" ){
            $spaceAdmin += $permission.principal.id
        }
    }

    return $spaceAdmin    
}
#$test = Get-SpaceAdmin -spaceID "8225423474"
#$test

$spaces = Get-AllSpaces
$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents'
foreach($space in $spaces){
    Write-Host "Starting $($space.name)"
    $startTime = Get-Date
    $lastUpdate = Get-LastPageUpdate -spaceID $space.id
    $admin = Get-SpaceAdmin -spaceID $space.id
    $adminText = $admin -join ","
   
    $csvOut += [ordered]@{
        "name" = if($space.name){$space.name}else{""}
        "key" = if($space.key){$space.key}else{""}
        "id" = if($space.id){$space.id}else{""}
        "createdAt" = if($space.createdAt){$space.createdAt}else{""}
        "createdByID" = if($space.authorId){$space.authorId}else{""}
        "type" = if($space.type){$space.type}else{""}
        "description" = if($space.description){$space.description}else {""}
        "link" = if($space._links.webui){"https://insurity.atlassian.net/wiki$($space._links.webui)"}else{""}
        "modifiedAt" = if($lastUpdate.version.createdAt.Date){$lastUpdate.version.createdAt.Date}else{""}
        "modifiedByID" = if($lastUpdate.version.authorId){$lastUpdate.version.authorId}else{""}
        "Admin" = if($adminText){$adminText}else{""}
    }
    $duration = NEW-TIMESPAN –Start $startTime –End $(Get-Date)
    Write-Host "Finshed in $duration"
}

$csvOut | Export-Csv -Path "$filePath\ConfluenceReport.csv"