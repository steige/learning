# Get an access token using your credentials

$token = (Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com" -AsSecureString).Token
$token = ConvertFrom-SecureString -SecureString $token -AsPlainText

# Future parameters
$groupName = "SEC-AAD-JIRA-JIRA-CAB-Members"
$userEmail = "patrick.graham@insurity.com"

# Get GroupID
$responce = Invoke-RestMethod -Method Get `
    -Uri "https://graph.microsoft.com/v1.0/groups?`$filter=displayName eq '$groupName'&`$select=id,displayName" `
    -Headers @{Authorization = "Bearer $token"}

if ($responce.value.Count -eq 1){
    $groupId = $responce.value[0].id
}

#Get UserID
$userId = (Invoke-RestMethod -Method Get `
    -Uri "https://graph.microsoft.com/v1.0/users/$userEmail" `
    -Headers @{Authorization = "Bearer $token"}).id


# Add member to group
<# $body = @{
    "@odata.id" = "https://graph.microsoft.com/v1.0/directoryObjects/$userId"
} | ConvertTo-Json

Invoke-RestMethod -Method Post `
    -Uri "https://graph.microsoft.com/v1.0/groups/$groupId/members/`$ref" `
    -Headers @{Authorization = "Bearer $token"} `
    -Body $body `
    -ContentType "application/json"  #>

# Remove member from group
Invoke-RestMethod -Method Delete `
    -Uri "https://graph.microsoft.com/v1.0/groups/$groupId/members/$userId/`$ref" `
    -Headers @{Authorization = "Bearer $token"}
