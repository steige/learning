Import-Module -Name CredentialManager
Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$credJira =[Convert]::ToBase64String($Bytes)

$cred = Get-StoredCredential -Target 'TargetProcess'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$credTP =[Convert]::ToBase64String($Bytes)

function Get-AtlassianID {
    param (
        [Parameter(Mandatory=$true)]
        [String]$user
    )

    $url = "https://insurity.atlassian.net/rest/api/3/user/search?query=$user"
    
    $headers = @{
        'Authorization' = "Basic $credJira"
        'Accept' = '*/*'
    }

    try {
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        if ($responce[1]){
            return 'Multiple'
        }
        return $responce[0].accountId, $responce[0].displayName
    }
    catch {
        return 'Not Found'
    }
    
}
function Get-TPAttachmentLinks {
    param (
        [Parameter(Mandatory=$true)]
        [string]$entitieID,
        [Parameter(Mandatory=$true)]
        [string]$entitieType
    )
    
    $returnObject = [ordered]@{
        'ID' = $entitieID
    }
        
    $url = "https://valenanalytics.tpondemand.com/api/v1/$entitieType/$entitieID/Attachments?format=json"
    
    $headers = @{
        'Authorization' = "Basic $credTP"
    }
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    if ($responce.Items){
        write-host("Getting attachments for $entitieID...")
    }
    else{
        write-host("No attachments for $entitieID...")
    }

    $count = 0
    foreach ($attachment in $responce.Items){
        $count++
        $title = "Attachment$count"
       
        $returnObject.add($title, "$($attachment.Date.ToString("dd/MMM/yy h:mm tt"))" + ";" + $attachment.Owner.FullName + ";" + $attachment.Name + ";" + "https://valenanalytics.tpondemand.com/attachment.aspx/?AttachmentID=$($attachment.ID)") 

    }

    return $returnObject
}

$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Valen'
$workItems = Import-Csv -Path "$filePath\itemsToMove.csv"
foreach ($row in $workItems){
    $csvOut += Get-TPAttachmentLinks -entitieID $row.ID -entitieType $row."Entity Type"
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending
$csvOut | Export-Csv -Path "$filePath\Finalattachments.csv"

#$test = Get-TPAttachmentLinks -entitieID '9027' -entitieType 'Features'
#$test