Import-Module -Name CredentialManager
$cred = Get-StoredCredential -Target 'TFS4Jira'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function GetRepos {
    param (
        $org,
        $project
    )

    $returnObject = @()
    $headers = @{
        'Authorization' = "Basic $cred"
    }
    
    $url = "https://dev.azure.com/$org/$project/_apis/git/repositories?api-version=4.1-preview.1"

    $responce = Invoke-RestMethod -Uri $url -Headers $headers -Method GET
    foreach ($repo in $responce.value){
        $returnObject += @{
            "id" = $repo.id
            "name" = $repo.name
        }
    }

    return $returnObject
}

function GetProjects {
    param (
        $org
    )

    $returnObject = @()
    $headers = @{
        'Authorization' = "Basic $cred"
    }
    
    $url = "https://dev.azure.com/$org/_apis/projects?api-version=4.1"

    $responce = Invoke-RestMethod -Uri $url -Headers $headers -Method GET
    foreach ($project in $responce.value){
        $returnObject += @{
            "id" = $project.id
            "name" = $project.name
        }
    }

    return $returnObject
}

$org = "InsurityAzureDevops"
$repoList = @()
$projects = GetProjects -org $org 

foreach ($project in $projects){
    $repos = GetRepos -org $org -project $project.name
    Write-Host "getting $($project.name) project"
    foreach($repo in $repos){
        if($repo.id -eq "a0ac24cb-77fa-47e8-8ab0-4e6d5b9a4db0"){
            Write-Host "FOUND $($repo.name)"
        }
        $repoList += $repo
    }
}
$repoList