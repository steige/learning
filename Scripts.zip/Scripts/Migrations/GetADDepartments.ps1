Import-Module AzureAD
Connect-AzureAD

$departments = Get-AzureADUser -filter * -property department | select -ExpandProperty department | sort-object  -unique
$departments