Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

<# Gets all 3700 users active or not.
$startAt = 0
$maxResults = 50
$userList = @()
$continue = $true

while ($continue) {
    $url = "https://insurity.atlassian.net/rest/api/3/users/search?startAt=$startAt&maxResults=$maxResults"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
    if ($responce){
        $userList += $responce
        $startAt += $responce.Count
    }
    else {
        $continue = $false
    }
} #>
    
function Get-AtlassianID {
    param (
        [Parameter(Mandatory=$true)]
        [String]$userID
    )

    $url = "https://insurity.atlassian.net/rest/api/3/user/search?query=$userID"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    try {
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        if ($responce[1]){
            return 'Multiple'
        }
        return $responce[0].accountId, $responce[0].displayName
    }
    catch {
        return 'Not Found'
        <# $url = "https://maprisk.atlassian.net/rest/api/3/user/search?query=$userID"

        try {
            $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        if ($responce[1]){
            return 'Multiple'
        }
        $id, $displayName = Get-AtlassianUser -userID $responce[0].accountId
        return $id, $displayName
        }
        catch {
            return "", "Not Active"
        } #>
    }
    
}
function Get-AtlassianUser {
    param (
        [Parameter(Mandatory=$true)]
        [String]$userID
    )

    $url = "https://insurity.atlassian.net/rest/api/3/user?accountId=$userID"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    try{
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        return $responce.accountId, $responce.displayName
    }
    catch{
        $url = "https://maprisk.atlassian.net/rest/api/3/user?accountId=$userID"

        try {
            $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
            $name = $responce.displayName.Replace(" ",".")
            $id, $displayName = Get-AtlassianID -userID $name
            return $id, $displayName
        }
        catch {
            return "", "Not Active"
        }
        
    }

    
}

$path = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Valen'

$users = Import-Csv -Path $($path + '\users.csv')

$export = @()

foreach ($user in $users){
    if($user.Name){
        $id, $displayName = Get-AtlassianID -userID $user.Name
        $export += @{
            "Original" = if($user.Original){$user.Original}else{""}
            "Name" = if($user.name){$user.name}else{""}
            "ID" = if($user.ID){$user.ID}else {""}
            "AtlassianID" = $id
            "AtlassianName" = $displayName
        }
    }
    else {
        $id, $displayName = Get-AtlassianUser -userID $user.ID
        $export += @{
            "Original" = if($user.Original){$user.Original}else{""}
            "Name" = if($user.name){$user.name}else{""}
            "ID" = if($user.ID){$user.ID}else {""}
            "AtlassianID" = $id
            "AtlassianName" = $displayName
        }
    }
}

$export.GetEnumerator() |
    Select-Object -Property Original,Name,ID,AtlassianID,AtlassianName |
        Export-Csv -NoTypeInformation -Path $($path + "\finalUsersTest.csv")