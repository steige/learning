Import-Module -Name CredentialManager
function Get-ADOWorkItemComments {
    param (
        [Parameter(Mandatory=$true)]
        [string]$workItemID,
        [string]$areaPath
    )
    
    $CommentList = @()
    $returnObject = [ordered]@{
        'ID' = $workItemID
    }

    $cred = Get-StoredCredential -Target 'DataHouse'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
    }
    
    $url = "http://hfdwpprodtfs:8080/tfs/Main/InsurityScrum/_apis/wit/workitems/$workItemID"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    $commentURL = $responce._links.workItemHistory.href

    if ($commentURL){
        write-host("Getting comments for $workItemID...")
        $commentResponce = Invoke-RestMethod -Method 'Get' -Uri $commentURL -Headers $headers
    }
    else{
        write-host("No comments for $workItemID...")
    }
    
    $count = 0
    foreach ($comment in $commentResponce.value){
        $html = New-Object -Com "HTMLFile"
        $html.write([ref]$comment.value)
        [String]$body = $html.body.innerText

        $count++
        $title = "Comment$count"
        $returnObject.add($title, "$($comment.revisedDate.ToString("dd/MMM/yy h:mm tt"));$($comment.revisedBy.displayName);$($body.replace("`n"," ").replace("`r"," "))")
    }

    return $returnObject
}

#Get-ADOWorkItemComments -workItemID "1000964" -areaPath "/DataHouse"
$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\DataHouse\Comments.csv'
$workItems = Import-Csv -Path $filePath
foreach ($row in $workItems){
    $csvOut += Get-ADOWorkItemComments -workItemID $row.ID
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending

$csvOut | Export-Csv -Path 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\DataHouse\FinalComments.csv' -Force