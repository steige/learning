Import-Module -Name CredentialManager
Import-Module -Name MarkdownPrince

$cred = Get-StoredCredential -Target 'TargetProcess'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$headers = @{
    'Authorization' = "Basic $cred"
}
function Get-EntityComments {
    param (
        [Parameter(Mandatory=$true)]
        [string]$entitieID,
        [Parameter(Mandatory=$true)]
        [string]$entitieType
    )
    
    $returnObject = [ordered]@{
        'ID' = $entitieID
    }
    
    $url = "https://valenanalytics.tpondemand.com/api/v1/$entitieType/$entitieID/Comments?format=json"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    if ($responce.Items){
        write-host("Getting comments for $entitieID...")
    }
    else{
        write-host("No comments for $entitieID...")
    }
    
    $count = 0
    foreach ($comment in $responce.Items){
        $Newbody = $comment.Description
        $NewformatedBody = ConvertFrom-HTMLToMarkdown -Content $Newbody -UnknownTags Bypass -Format

        <# $html = New-Object -Com "HTMLFile"
        $html.write([ref]$comment.Description)
        [String]$body = $html.body.innerText
        $formatedBody = $body.replace("`n"," ").replace("`r"," ") #>

        $count++
        $title = "Comment$count"
        
        $returnObject.add($title, "$($comment.CreateDate.ToString("dd/MMM/yy h:mm tt"));$($comment.Owner.FullName);$NewformatedBody")
    }

    return $returnObject
}

$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Valen'
$workItems = Import-Csv -Path "$filePath\itemsToMove.csv"
foreach ($row in $workItems){
    $csvOut += Get-EntityComments -entitieID $row.ID -entitieType $row."Entity Type"
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending

$csvOut | Export-Csv -Path "$filePath\FinalComments.csv" -Force 

#$test = Get-EntityComments -entitieID '984' -entitieType 'Requests'
#$test