Import-Module -Name CredentialManager
Import-Module -Name MarkdownPrince

$cred = Get-StoredCredential -Target 'TargetProcess'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$headers = @{
    'Authorization' = "Basic $cred"
}
function Get-SOWFields {
    param (
        [Parameter(Mandatory=$true)]
        [string]$entitieID,
        [Parameter(Mandatory=$true)]
        [string]$entitieType
    )

    $returnObject = [ordered]@{
        'ID' = $entitieID
    }
    
    $url = "https://valenanalytics.tpondemand.com/api/v1/$entitieType/$entitieID"+"?format=json&include=[creator,name,SOW SME]"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    if ($responce){
        write-host("Getting Feilds for $entitieID...")
        $returnObject.add("Summary",$responce.name)
        $returnObject.add("Description",$NewformatedBody)
    }
    if($responce.Description){
        write-host("Getting Description for $entitieID...")
        $NewformatedBody = ConvertFrom-HTMLToMarkdown -Content $responce.Description -UnknownTags Bypass -Format
    }
    else {
        write-host("No Description for $entitieID...")
        $NewformatedBody = ""
    }

    $returnObject.add("Description",$NewformatedBody)

    return $returnObject
}

$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Valen'
$workItems = Import-Csv -Path "$filePath\itemsToMove.csv"
foreach ($row in $workItems){
    $csvOut += Get-SOWFields -entitieID $row.ID -entitieType $row."Entity Type"
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending

$csvOut | Export-Csv -Path "$filePath\FinalDescription.csv" -Force 