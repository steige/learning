Import-Module -Name CredentialManager
function Get-ADOWorkItemAttachmentLinks {
    param (
        [Parameter(Mandatory=$true)]
        [string]$workItemID
    )
    
    $returnObject = [ordered]@{
        'ID' = $workItemID
    }

    $cred = Get-StoredCredential -Target 'DataHouse'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
    }
    # 'ContentType' = "application/octet-stream"
    
    $url = "http://hfdwpprodtfs:8080/tfs/Main/InsurityScrum/_apis/wit/workitems/$workItemID"+'?$expand=relations'

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    $count = 0
    foreach ($relation in $responce.relations){
        #$test = $relation.url -match '_apis/wit/attachments'
        if ($relation.url -match '_apis/wit/attachments'){
            $count++
            $title = "Attachment$count"
            $returnObject.add($title, "$($relation.attributes.resourceCreatedDate.ToString("dd/MMM/yy h:mm tt"))"+";"+"micah.harley;"+"$($relation.attributes.name)"+";"+$relation.url)
        }

    }

    $HTML = New-Object -Com "HTMLFile"
    [string]$htmlBody = $responce.fields.'System.Description'
    $HTML.write([ref]$htmlBody)
    $filter = $HTML.getElementsByTagName('img')

    foreach ($img in $filter){
        $temp = $img.src.Split('?')
        $path = $temp[0]
        $filename = $temp[1].Split('=')[1]

        $count++
        $title = "Attachment$count"
        $returnObject.add($title, "$("01/Jan/22 0:00 AM;micah.harley;" + $filename + ";" + $path)")
    }

    return $returnObject
}

<# $csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\InstecADO\Attachments.csv'
$workItems = Import-Csv -Path $filePath
foreach ($row in $workItems){
    $csvOut += Get-ADOWorkItemAttachmentLinks -workItemID $row.ID
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending
$csvOut | Export-Csv -Path $filePath  #>

$test = Get-ADOWorkItemAttachmentLinks -workItemID '979194'
$test