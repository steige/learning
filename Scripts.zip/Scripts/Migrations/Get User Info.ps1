Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-UserInfo {
    param (
        [Parameter(Mandatory=$true)]
        [String]$AccountID
    )
    
    $url = "https://insurity.atlassian.net/gateway/api/directory/graphql?q=UserDetails"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Content-Type' = "application/json"
    }

    $body = '{
        "query": "query UserDetails($userId: String!, $cloudId: String!) {\r\n  CloudUser(userId: $userId, cloudId: $cloudId) {\r\n    id\r\n    fullName\r\n    isCurrentUser\r\n    title\r\n    department\r\n    companyName\r\n    location\r\n    timezone\r\n    email\r\n    phoneNumber\r\n    remoteWeekdayIndex: localTime(format: \"d\")\r\n    remoteWeekdayString: localTime(format: \"ddd\")\r\n    remoteTimeString: localTime(format: \"h:mma ([GMT]Z)\")\r\n    __typename\r\n  }\r\n}\r\n",
        "variables": {
            "cloudId": "10188398-9a01-4bcb-806e-54f4d019a605",
            "userId": "' + $AccountID + '"
        }
    }'

    $responce = Invoke-RestMethod -Method Post -Uri $url -Headers $headers -Body $body

    return $responce.data.CloudUser
}
$csvOut = @()
$users = Import-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\confluenceUsers.csv"
foreach($user in $users){
    $userData = Get-UserInfo -AccountID $user.id
    $csvOut += [ordered]@{
        "id" = $user.id
        "department" = if($userData.department){$userData.department}else {""}
        "job title" = if($userData.title){$userData.title}else {""}
    }
}

$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\userReport.csv"
