Import-Module -Name CredentialManager
$cred = Get-StoredCredential -Target 'ADO'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-ADOWorkItemAttachmentLinks {
    param (
        [Parameter(Mandatory=$true)]
        [string]$workItemID
    )
    
    Write-Host "Processing $workItemID"

    $returnObject = [ordered]@{
        'ID' = $workItemID
    }

    $headers = @{
        'Authorization' = "Basic $cred"
    }
    # 'ContentType' = "application/octet-stream"
    
    $url = "https://dev.azure.com/Insteccorp/_apis/wit/workitems/$workItemID"+'?$expand=relations'

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    $count = 0
    foreach ($relation in $responce.relations){
        #$test = $relation.url -match '_apis/wit/attachments'
        if ($relation.url -match '_apis/wit/attachments'){
            $count++
            $title = "Attachment$count"
            $path = $relation.url + "?fileName=" + $($relation.attributes.name).replace(' ','%20')
            $returnObject.add($title, "$($relation.attributes.resourceCreatedDate.ToString("dd/MMM/yy h:mm tt"))"+";"+"micah.harley;"+"$($relation.attributes.name)"+";"+$path)
        }

    }

    $HTML = New-Object -Com "HTMLFile"
    [string]$htmlBody = $responce.fields.'System.Description'
    $HTML.write([ref]$htmlBody)
    $filter = $HTML.getElementsByTagName('img')

    foreach ($img in $filter){
        $temp = $img.src.Split('?')
        $filename = $temp[1].Split('=')[1]
        $path = $temp[0] + "?fileName=" + $filename.replace(' ','%20')
        $count++
        $title = "Attachment$count"
        $returnObject.add($title, "$("01/Jan/22 0:00 AM;micah.harley;" + $filename + ";" + $path)")
    }

    return $returnObject
}

$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Upland Migration\Comments.csv'
$workItems = Import-Csv -Path $filePath
foreach ($row in $workItems){
    $csvOut += Get-ADOWorkItemAttachmentLinks -workItemID $row.ID
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending
$csvOut | Export-Csv -Path 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Upland Migration\finalAttachments.csv'

#$test = Get-ADOWorkItemAttachmentLinks -workItemID '248760'
#$test