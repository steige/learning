Import-Module -Name CredentialManager
$cred = Get-StoredCredential -Target 'ADO'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-ADOWorkItemComments {
    param (
        [Parameter(Mandatory=$true)]
        [string]$workItemID,
        [string]$areaPath
    )
    
    $returnObject = [ordered]@{
        'ID' = $workItemID
    }

    $headers = @{
        'Authorization' = "Basic $cred"
    }
    
    $url = "https://dev.azure.com/Insteccorp/Instec/_apis/wit/workitems/$workItemID"+"?api-version=6.0"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    $commentURL = $responce._links.workItemComments.href

    if ($commentURL){
        write-host("Getting comments for $workItemID...")
        $commentResponce = Invoke-RestMethod -Method 'Get' -Uri $commentURL -Headers $headers
    }
    else{
        write-host("No comments for $workItemID...")
    }
    
    $count = 0
    foreach ($comment in $commentResponce.comments){
        $html = New-Object -Com "HTMLFile"
        $html.write([ref]$comment.text)
        [String]$body = $html.body.innerText

        $count++
        $title = "Comment$count"
        $returnObject.add($title, "$($comment.createdDate.ToString("dd/MMM/yy h:mm tt"));$($comment.createdBy.displayName);$($body.replace("`n"," ").replace("`r"," "))")
    }

    return $returnObject
}

#Get-ADOWorkItemComments -workItemID "1000964" -areaPath "/DataHouse"
 $csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Upland Migration\Comments.csv'
$workItems = Import-Csv -Path $filePath
foreach ($row in $workItems){
    $csvOut += Get-ADOWorkItemComments -workItemID $row.ID
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending

$csvOut | Export-Csv -Path 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Upland Migration\CommentsList.csv' -Force