$location = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Valen"
$userlist = Import-Csv -Path $($location + "\finalUsersTest.csv")
$migrationFile = Get-Content $($location + "\Finalsubtasks.csv") -Raw

foreach ($user in $userlist){
    $migrationFile = $migrationFile -replace $user.Original, $user.AtlassianID
}

$migrationFile | Out-File $($location + "\Finalsubtasks Replaced.csv")