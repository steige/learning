Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'TargetProcess'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$headers = @{
    'Authorization' = "Basic $cred"
}
$global:subtaskCount = 1
function Create-Subtask {
    param (
        [Parameter(Mandatory=$true)]
        [string]$ID,
        [Parameter(Mandatory=$true)]
        [string]$EntityType
    )

    $returnObject = @()

    $url = "https://valenanalytics.tpondemand.com/api/v1/$EntityType/"+$ID+"?format=json&include=[AssignedEfforts[Effort,Role,GeneralUser],Creator[email]]"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    if ($responce.AssignedEfforts.Items){
        Write-Host "Getting Assignments for $EntityType $ID"
        foreach($assignment in $responce.AssignedEfforts.Items){
            if ($assignment.Effort -gt 0){
                $tempObject = [ordered]@{
                }
                if($assignment.GeneralUser.FullName){$assignee=$assignment.GeneralUser.FullName}else {$assignee=""}
                $tempObject.Add("IssueID", ($global:subtaskCount))
                $tempObject.Add("Summary", $assignment.Role.Name)
                $tempObject.Add("Assignee", $assignee)
                $tempObject.Add("Parent", $ID)
                $tempObject.Add("Reporter", $responce.Creator.Email)
                $tempObject.Add("IssueType", "Dev")
                $tempObject.Add("OriginalEstimate", ($assignment.Effort * 3600))

                $returnObject += ($tempObject)
                $global:subtaskCount += 1
            }
        }
    }
    else {
        Write-Host "No Assignments for $EntityType $ID"
    }
    return $returnObject
    
}
$csvOut = @()
$filePath = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Valen'
$workItems = Import-Csv -Path "$filePath\itemsToMove.csv"
foreach ($row in $workItems){
    $temp = Create-Subtask -ID $row.ID -EntityType $row."Entity Type"
    if ($temp){$csvOut += $temp}
}

$csvOut = $csvOut | Sort-Object { $_.count } -Descending
$csvOut | Export-Csv -Path "$filePath\Finalsubtasks.csv"

#$test = Create-Subtask -ID '15651' -EntityType 'Userstory'
#$test