Import-Module -Name CredentialManager

$Logfile = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\VMGA\JessErrors.log"

Function LogWrite
{
   Param ([string]$logstring)

   Add-content $Logfile -value $logstring
}

function Get_Tempo_Worklogs_By_ID {
    param (
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [String]$worklogID
    )

    $url = "https://api.tempo.io/core/3/worklogs/$worklogID"

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
    }

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    return $responce

}

function Add_Tempo_Worklog {
    param (
        [Parameter(Mandatory=$true)]
        [string]$logID,
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [String]$issueKey,
        [Parameter(Mandatory=$true)]
        [int]$time,
        [Parameter(Mandatory=$true)]
        [string]$startDate,
        [Parameter(Mandatory=$true)]
        [string]$startTime,
        [Parameter()]
        [String]$description,
        [Parameter(Mandatory=$true)]
        [String]$accountID
    )

    $url = "https://api.tempo.io/core/3/worklogs"

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
        'content-type' = "application/json"
    }

    $body = @{
        'issueKey' = $issueKey
        'timeSpentSeconds' = $time
        'startDate' = $startDate
        'startTime' = $startTime
        'description' = $description
        'authorAccountId' = $accountID
    } | ConvertTo-Json

    Try{
        $responce = Invoke-RestMethod -Method 'Post' -Uri $url -Headers $headers -Body $body
    }
    Catch{
        $ErrorString = $Error[0], $logID, $issueKey, $accountID
        Write-Host $ErrorString
        LogWrite $ErrorString
    }

    return $responce
    
}

# Retrieves the Access Token for VMGA's Tempo instance
$vmgaCred = Get-StoredCredential -Target 'TempoVMGA'
$accessTokenVMGA = $vmgaCred.Password

# Retrieves the Access Token for Insurity's Tempo instance
$prodCred = Get-StoredCredential -Target 'TempoProd'
$accessTokenforProd = $prodCred.Password

# List of logs that should go to Jess
$Jessworklogs = Import-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\VMGA\JessWorkLogs.csv"

foreach ($log in $Jessworklogs){
    $orignalLog = Get_Tempo_Worklogs_By_ID -token $accessTokenVMGA -worklogID $log.WorkLogID
    $JessAccountID = "5d4c22d2cca0cf0c56be3666"
    $result = Add_Tempo_Worklog -logID $orignalLog.tempoWorklogId -token $accessTokenforProd -issueKey $orignalLog.issue.key -time $orignalLog.timeSpentSeconds -startDate $orignalLog.startDate -startTime $orignalLog.startTime  -description $orignalLog.description -accountID $JessAccountID
}