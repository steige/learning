Import-Module -Name CredentialManager

$OGLogfile = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\VMGA\OGLogs.log"
$ProdLogfile = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\VMGA\ProdLogs.log"

Function LogWrite
{
   Param (
        [string]$logstring,
        [string]$Logfile
    )

   Add-content $Logfile -value $logstring
}

function Get_Tempo_Worklogs {
    param (
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [String]$issueKey
    )

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
    }
    
    $offset = 0
    $continue = $true
    $returnValues = @()

    while ($continue) {
        $url = "https://api.tempo.io/core/3/worklogs/issue/"+$issueKey+"?from=2018-1-1&to=2021-8-20&limit=1000&offset="+$offset
        
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        
        $returnValues += $responce.results

        if ($responce.metadata.next){
            $offset += 1000
        }
        else {
            $continue = $false
        }
    }
    return $returnValues
}

$vmgaCred = Get-StoredCredential -Target 'TempoVMGA'
$prodCred = Get-StoredCredential -Target 'TempoProd'

$accessTokenVMGA = $vmgaCred.Password
$accessTokenforProd = $prodCred.Password

$OGworklogs = Get_Tempo_Worklogs -token $accessTokenVMGA -issueKey "PD-1594"
foreach ($log in $OGworklogs){
    $logString = $log.tempoWorklogId, $log.issue.key, $log.timeSpentSeconds, $log.startDate, $log.startTime, $log.author.accountID
    LogWrite -logstring $logString -Logfile $OGLogfile
}

$Prodworklogs = Get_Tempo_Worklogs -token $accessTokenforProd -issueKey "MNIGHTNOVA-1594"
foreach ($log in $Prodworklogs){
    $logString = $log.tempoWorklogId, $log.issue.key, $log.timeSpentSeconds, $log.startDate, $log.startTime, $log.author.accountID
    LogWrite -logstring $logString -Logfile $ProdLogfile
}