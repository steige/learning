Import-Module -Name CredentialManager

$prodCred = Get-StoredCredential -Target 'TempoProd'
$Plaintoken = ConvertFrom-SecureString $prodCred.Password -AsPlainText
$tempoHeaders = @{
    'Authorization' = "Bearer $Plaintoken"
}
$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Get-User {
    param (
        [Parameter(Mandatory=$true)]
        [string]$atlassianID
    )

    $url = "https://insurity.atlassian.net//rest/api/3/user?accountId=$atlassianID"

    $responce = Invoke-RestMethod -Uri $url -Method Get -Headers $headers
    
    return @{
        "displayName" = $responce.displayName
        "emailAddress" = $responce.emailAddress
    }
}

function Get-PermissionRoles {
    param (
        [Parameter(Mandatory=$true)]
        [string]$teamID
    )

    $TeamManagers = @()
    $WorklogManagers = @()
    $WorklogApprovers = @()
    
    $url = "https://api.tempo.io/4/permission-roles?teamId=$teamID"
    $responce = Invoke-RestMethod -Uri $url -Method Get -Headers $tempoHeaders
    
    foreach ($role in $responce.results){
        foreach ($permission in $role.permissions){
            if($permission.key -like "permissions.team.manage"){
                foreach ($user in $role.permittedUsers){
                    $userObject = Get-User -atlassianID $user.accountId
                    $TeamManagers += $userObject.displayName
                }
            }
            if($permission.key -like "permissions.worklog.approve"){
                foreach ($user in $role.permittedUsers){
                    $userObject = Get-User -atlassianID $user.accountId
                    $WorklogApprovers += $userObject.displayName
                }
            }
            if($permission.key -like "permissions.worklog.manage"){
                foreach ($user in $role.permittedUsers){
                    $userObject = Get-User -atlassianID $user.accountId
                    $WorklogManagers += $userObject.displayName
                }
            }
        }
        
    }
    $TeamManagers = $TeamManagers | Join-String -DoubleQuote -Separator ','
    $WorklogApprovers = $WorklogApprovers | Join-String -DoubleQuote -Separator ','
    $WorklogManagers = $WorklogManagers | Join-String -DoubleQuote -Separator ','

    return @{
        "TeamManagers" = $TeamManagers
        "WorklogApprovers" = $WorklogApprovers
        "WorklogManagers" = $WorklogManagers
    }
}

function Get-TeamMembers {
    param (
        [Parameter(Mandatory=$true)]
        [string]$teamID
    )

    $url = "https://api.tempo.io/4/teams/$teamID/members"
    $responce = Invoke-RestMethod -Uri $url -Method Get -Headers $tempoHeaders

    $returnList = @()
    
    foreach($member in $responce.results){
        $userObject = Get-User -atlassianID $member.member.accountId
        $returnList += @{
            "name" = $userObject.displayName
            "email" = $userObject.emailAddress
        }
    }

    return $returnList
}

$csvOut = @()

$url = "https://api.tempo.io/4/teams"
$responce = Invoke-RestMethod -Uri $url -Method Get -Headers $tempoHeaders

foreach ($team in $responce.results){
    $teamPermissions = Get-PermissionRoles -teamID $team.id
    $lead = Get-User -atlassianID $team.lead.accountId
    $members = Get-TeamMembers -teamID $team.id

    foreach ($member in $members){
        $csvOut += @{
            "Name" = if($member.name){$member.name}else{""}
            "Email" = if($member.email){$member.email}else{""}
            "Team" = if($team.name){$team.name}else{""}
            "TeamLead" = if($lead.displayName){$lead.displayName}else{""}
            "ManageTeam" = if($teamPermissions.teamManagers){$teamPermissions.teamManagers}else{""}
            "ApproveWorklogs" = if($teamPermissions.worklogApprovers){$teamPermissions.worklogApprovers}else{""}
            "ManageWorklogs" = if($teamPermissions.worklogManagers){$teamPermissions.worklogManagers}else{""}
        }
    }
    
}

$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Scripts\TempoUsers.csv" -Force 