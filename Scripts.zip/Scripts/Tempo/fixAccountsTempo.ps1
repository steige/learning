Import-Module -Name CredentialManager
$prodCred = Get-StoredCredential -Target 'TempoProd'
$sandCred = Get-StoredCredential -Target 'TempoSandbox'


function Get_Tempo_Accounts {
    param (
        [Parameter(Mandatory=$true)]
        [securestring]$token
    )

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
    }
    
    $returnValues = @()

    $url = "https://api.tempo.io/core/3/accounts"
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
    $returnValues += $responce.results

    return $returnValues
}
function Get_Tempo_Account_Sandbox {
    param (
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [string]$id
    )

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
    }
    
    $returnValues = @()

    $url = "https://api.tempo.io/core/3/accounts?id=$id"
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
    $returnValues += $responce.results

    return $returnValues
}
function Set_Sandbox_Account_Name {
    param (
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [string]$key,
        [Parameter(Mandatory=$true)]
        [string]$prodkey,
        [Parameter(Mandatory=$true)]
        [string]$name,
        [Parameter(Mandatory=$true)]
        [string]$status,
        [Parameter(Mandatory=$true)]
        [string]$leadAccountId,
        [Parameter(Mandatory=$true)]
        [string]$global
    )

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
        'Content-Type' = "application/json"
    }

    $body = @{
        "key"= $prodkey
        "name"= $name
        "status"= $status
        "leadAccountId"= $leadAccountId
        "contactAccountId" = $contactAccountId
        "customerKey" = $customerKey
        "monthlyBudget" = $monthlyBudget
        "global" = $global
    } | ConvertTo-Json

    $url = "https://api.tempo.io/core/3/accounts/$key"
    
    Invoke-RestMethod -Method 'Put' -Uri $url -Headers $headers -Body $body
}

#Get all accounts
$accounts = Get_Tempo_Accounts -token $prodCred.Password

#foreach Account
foreach ($account in $accounts){
    #Get sandbox account key
    $sandAccount = Get_Tempo_Account_Sandbox -token $sandCred.Password -id $account.id

    #Update sandbox account with name of prod account
    Set_Sandbox_Account_Name -token $sandCred.Password -key $sandAccount.key -prodkey $account.key -name $account.name -status $account.status -leadAccountId $account.lead.accountId -global $account.global    
}
