Import-Module -Name CredentialManager
$prodCred = Get-StoredCredential -Target 'TempoProd'
$token = $prodCred.Password
$accesstoken = ConvertFrom-SecureString $token -AsPlainText

# Get All Tempo Teams
$headers = @{
    'Authorization' = "Bearer $accesstoken"
}

$continue = $true
$offset = 0
$teamList = @()
$url = "https://api.tempo.io/4/teams?offset=$offset"

while ($continue) {
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    foreach ($team in $responce.results){
        $teamList += @{
            id = $team.id
            name = $team.name
        }
    }

    if($responce.metadata.next){
        $url = $responce.metadata.next
    }
    else {
        $continue = $false
    }
}

$path = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\TempoTeams"
$items = Import-Csv -Path "$path\TempoTeamsReplaced.csv"

# For Each Row
foreach ($item in $items){
    # Check if Team Exists
    if ($teamList.name.Contains($item.Team)){
        # If so, Add user to Team
        'exists'
       
    }else{
        # If not, create Team
        'Nope'
        
    }
}