Import-Module -Name CredentialManager

function Add-TempoMembership {
    param (
        [Parameter(Mandatory=$true)]
        [string]$atlassianID,
        [Parameter(Mandatory=$true)]
        [string]$tempoTeamID,
        [Parameter()]
        [string]$toDate
    )
    
    $Cred = Get-StoredCredential -Target 'TempoSandbox'
    $accessToken = $Cred.Password
    $accessToken = ConvertFrom-SecureString $accessToken -AsPlainText
    
    $headers = @{
        'Authorization' = "Bearer $accessToken"
        'Content-Type' =  "application/json"
    }

    $body = @{
        "accountId" = $atlassianID
        "teamId" = $tempoTeamID
    } | ConvertTo-Json
    
    $url = "https://api.tempo.io/4/team-memberships"

    $responce = Invoke-RestMethod -Method Post -Uri $url -Headers $headers -Body $body

    if ($responce){
        return $responce
    }
    else {
        return 'Something went wrong'
    }
}

$file = Import-Csv -Path 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\userfix.csv'
foreach ($user in $file){
    Add-TempoMembership -atlassianID $user.AtlassianID -tempoTeamID $user.TestTeamID
}
