Import-Module -Name CredentialManager

$credTempo = Get-StoredCredential -Target 'TempoProd'
$tokenTempo = ConvertFrom-SecureString $credTempo.Password -AsPlainText

# Gets Username and APIToken from Windows Credential Manager and formats for Jira api call
$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$credJira =[Convert]::ToBase64String($Bytes)

function Get-TempoWorklogs {
    param ()

    Write-Host "`nGetting Tempo Logs..."

    $headers = @{
        'Authorization' = "Bearer $tokenTempo"
    }
    
    $offset = 0
    $continue = $true
    $returnValues = @()

    #calculate date range
    $today = GET-DATE -Hour 0 -Minute 0 -Second 0
    $MonthAgo = $today.AddMonths(-1)
    $firstofMonth = GET-DATE $MonthAgo -Day 1
    $lastofMonth = GET-DATE $firstofMonth.AddMonths(1).AddSeconds(-1)
    $firstofMonth = $firstofMonth.ToString("yyyy-M-d")
    $lastofMonth = $lastofMonth.ToString("yyyy-M-d")

    while ($continue) {
        $url = "https://api.tempo.io/core/3/worklogs/jira/filter/11539?limit=1000&offset=$offset&from=$firstofMonth&to=$lastofMonth"
        
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        
        $returnValues += $responce.results

        Write-Host "Recieved $($returnValues.Count) logs... "
        if ($responce.metadata.next){
            $offset += $responce.metadata.count
        }
        else {
            $continue = $false
        }
    }
    Write-Host "Finished getting Tempo Logs..."
    return $returnValues
}

function Get-JiraIssues {
    param (
        [Parameter()]
        [string]$jql="filter=11539"
    )
    
    Write-Host "Getting Jira issues..."

    $headers = @{
        'Authorization' = "Basic $credJira"
        'Accept' = '*/*'
    }

    # Initialize function variables
    $continue = $true
    $startAt = 0
    $returnIssues = @()
    $fieldList = @(
        "summary",
        "parent",
        "issuetype",
        "customfield_10055",
        "customfield_10030",
        "customfield_10074",
        "customfield_10285",
        "customfield_10300",
        "customfield_10033"
    ) -join ","

    # Starts a looping api call while there are still issues to get
    while ($continue) {
        $url = "https://insurity.atlassian.net/rest/api/3/search?jql=$jql&fields=$fieldList&startAt=$startAt&maxResults=100"
    
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        
        $returnIssues += $responce.issues

        if ($responce.total -gt ($responce.maxResults + $startAt)){
            $startAt += $responce.maxResults
        }
        else {
            $continue = $false
        }
    }
    return $returnIssues
}

function Get-ParentFields {
    param (
        [Parameter()]
        [string]$issueKey
    )

    $headers = @{
        'Authorization' = "Basic $credJira"
        'Accept' = '*/*'
    }
    
    $fieldList = @(
        "parent",
        "issuetype",
        "customfield_10075",
        "customfield_10011",
        "customfield_10097"
    ) -join ","

    $continue = $true
    $epicName = ""
    $PPMProjectID = ""
    $allocationCategory = ""

    while($continue){
        #Get issue
        $url = 'https://insurity.atlassian.net/rest/api/3/issue/'+$issueKey+'?fields='+$fieldList

        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

        If ($responce.fields.issuetype.name -eq "Initiative"){
            $PPMProjectID = $responce.fields.customfield_10075
            $continue = $false
        }
        elseif ($responce.fields.issuetype.name -eq "Epic") {
            $epicName = $responce.fields.customfield_10011
            $allocationCategory = $responce.fields.customfield_10097.value
        } 
        
        if($responce.fields.parent){
            $issueKey = $responce.fields.parent.key
        }
        else {
            $continue = $false
        }
        
    }

    return $PPMProjectID, $epicName, $allocationCategory
}

$jiraIssues = Get-JiraIssues
$worklogs = Get-TempoWorklogs
$parentIssueFields = @()

Write-Host "Getting Parent Fields..."
foreach($issue in $jiraIssues){
    $projectID, $epicName, $allocationCategory = Get-ParentFields -issueKey $issue.key
    $parentIssueFields += @{
        "issueKey" = $issue.key
        "PPMProjectID" = $projectID
        "epicName" = $epicName
        "allocationCategory" = $allocationCategory
    }
}

$csvList = @()
Write-Host "Processing Worklogs... "
foreach ($log in $worklogs){
    $issue = $jiraIssues | Where-Object {$_.key -eq $log.issue.key}
    $parent = $parentIssueFields | Where-Object {$_.issueKey -eq $log.issue.key}
    
    # Looks for Work Type attribute on the worklog... later we use issue type if this is empty
    $worktype = $log.attributes.value | Where-Object {$_.key -eq "_WorklogType_"}

    $csvList += [ordered] @{
        "Full Name" = if($log.author.displayName){$log.author.displayName}else{"No Name"}
        "Client" = if($issue.fields.customfield_10055.value){$issue.fields.customfield_10055.value}else{""}
        "Project Name" = if($issue.fields.customfield_10030.value){$issue.fields.customfield_10030.value}else {""}
        "Project Type" = if($issue.fields.customfield_10074.value){$issue.fields.customfield_10074.value}else {""}
        "Billable" = if($issue.fields.customfield_10285.value){$issue.fields.customfield_10285.value}else {""}
        "Project ID" = if($parent.PPMProjectID){$parent.PPMProjectID}else{""}
        "Date" = if($log.startDate){$log.startDate}else{""}
        "Hours" = if($log.timeSpentSeconds){$log.timeSpentSeconds / 3600}else{""}
        "Activity" = if($worktype){$worktype.value}else {$issue.fields.issuetype.name}
        "SourceSystemID" = if($issue.key){$issue.key}else{""}
        "Title" = if($issue.fields.summary){$issue.fields.summary}else{""}
        "ParentID" = if($issue.fields.parent.key){$issue.fields.parent.key}else {""}
        "ParentTitle" = if($issue.fields.parent.fields.summary){$issue.fields.parent.fields.summary}else{""}
        "EpicLink" = if($parent.epicName){$parent.epicName}else{""}
        "Allocation Category" = if($parent.allocationCategory){$parent.allocationCategory}else{""}
        "Product" = if($issue.fields.customfield_10033.value){$issue.fields.customfield_10033.value}else{""}
    }
}

$csvList | Export-Csv -Path ".\report.csv"