Import-Module -Name CredentialManager
$prodCred = Get-StoredCredential -Target 'TempoProd'
$token = $prodCred.Password
$accesstoken = ConvertFrom-SecureString $token -AsPlainText

# Get All Tempo Teams
$headers = @{
    'Authorization' = "Bearer $accesstoken"
}

$continue = $true
$offset = 0
$teamList = @()
$url = "https://api.tempo.io/4/teams?offset=$offset"

while ($continue) {
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    foreach ($team in $responce.results){
        $teamList += @{
            id = $team.id
            name = $team.name
        }
    }

    if($responce.metadata.next){
        $url = $responce.metadata.next
    }
    else {
        $continue = $false
    }
}

# Function to create Team
function New-TempoTeam {
    param (
        [Parameter(Mandatory=$true)]
        [String]$name,
        [Parameter(Mandatory=$true)]
        [String]$leadID
    )

    #First create the Team
    $url = 'https://api.tempo.io/4/teams'

    $headers = @{
        'Authorization' = "Bearer $accesstoken"
        'Content-Type' = "application/json"
    }

    $body = @{
        "leadAccountId"= $leadID
        "name"= $name
    } | ConvertTo-Json

    $newTeam = Invoke-RestMethod -Method "POST" -Uri $url -Headers $headers -Body $body
    return $newTeam.name, $newTeam.id
}

#Function to create Permission Role
function Add-PermissionRole {
    param (
        [Parameter(Mandatory=$true)]
        [String]$teamID,
        [Parameter(Mandatory=$true)]
        [String]$memberID
    )
    #Then create a backup aprroval role
    $url = 'https://api.tempo.io/4/permission-roles'

    $headers = @{
        'Authorization' = "Bearer $accesstoken"
        'Content-Type' = "application/json"
    }

    $body = @{
        "accessEntityIds" = @($teamID)
        "accessType" = "TEAM"
        "name" = "Backup Approver"
        "permissionKeys" = @(
            "permissions.worklog.view",
            "permissions.worklog.manage",
            "permissions.worklog.approve",
            "permissions.team.manage"
        )
        "permittedAccountIds" = @($memberID)
    } | ConvertTo-Json

    Invoke-RestMethod -Method "POST" -Uri $url -Headers $headers -Body $body

}

# Function to add user to Team
function Add-TempoMembership {
    param (
        [Parameter(Mandatory=$true)]
        [String]$teamID,
        [Parameter(Mandatory=$true)]
        [String]$memberID
    )

    $url = 'https://api.tempo.io/4/team-memberships'

    $headers = @{
        'Authorization' = "Bearer $accesstoken"
        'Content-Type' = "application/json"
    }

    $body = @{
        "accountId" = $memberID
        "teamId" = $teamID
    } | ConvertTo-Json

    Invoke-RestMethod -Method 'POST' -Uri $url -Headers $headers -Body $body 
}

# Import CSV
$path = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\TempoTeams"
$items = Import-Csv -Path "$path\TempoTeams.csv"

# For Each Row
foreach ($item in $items){
    # Check if Team Exists
    if ($teamList.name.Contains($item.Team)){
        # If so, Add user to Team
        'exists'
        $team = $teamList | Where-Object name -eq $item.Team
        Add-TempoMembership -teamID $team.id -memberID $item.'Team Member'
    }else{
        # If not, create Team
        'Nope'
        $newTeamName, $newTeamID = New-TempoTeam -name $item.Team -leadID $item.Manager

        $teamList += @{
            id = $newTeamID
            name = $newTeamName
        }

        #create permission role
        Add-PermissionRole -teamID $newTeamID -memberID $item.'Backup Approver'
        # Then, Add user to Team
        Add-TempoMembership -teamID $newTeamID -memberID $item.'Team Member'
    }
}