Import-Module -Name CredentialManager

$Logfile = "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\VMGA\Finalerrors.log"

Function LogWrite
{
   Param ([string]$logstring)

   Add-content $Logfile -value $logstring
}
function Get_Tempo_Worklogs {
    param (
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [String]$issueKey
    )

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
    }
    
    $offset = 0
    $continue = $true
    $returnValues = @()

    while ($continue) {
        $url = "https://api.tempo.io/core/3/worklogs/issue/"+$issueKey+"?from=2021-8-21&to=2021-10-7&limit=1000&offset="+$offset
        
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        
        $returnValues += $responce.results

        if ($responce.metadata.next){
            $offset += 1000
        }
        else {
            $continue = $false
        }
    }
    return $returnValues
}

function Add_Tempo_Worklog {
    param (
        [Parameter(Mandatory=$true)]
        [string]$logID,
        [Parameter(Mandatory=$true)]
        [securestring]$token,
        [Parameter(Mandatory=$true)]
        [String]$issueKey,
        [Parameter(Mandatory=$true)]
        [int]$time,
        [Parameter(Mandatory=$true)]
        [string]$startDate,
        [Parameter(Mandatory=$true)]
        [string]$startTime,
        [Parameter()]
        [String]$description,
        [Parameter(Mandatory=$true)]
        [String]$accountID
    )
    
    
    # Write Harry's logs to Gareth
    if ($accountID -eq '5ebc0716767b660b7762b734'){
        $accountID = '5d51505cba0a060da21fc36c'
        $description += ' Logged from: Harry Martin'
    }

    # Write Ryan Chandler's logs to Jess
    if ($accountID -eq '5d601389faa9600c3609a47a'){
        $accountID = '5d4c22d2cca0cf0c56be3666'
        $description += ' Logged from: Ryan Chandler'
    }

    # Write Nikola's logs to Jess
    if ($accountID -eq '5da850d01741650c3b1e0806'){
        $accountID = '5d4c22d2cca0cf0c56be3666'
        $description += ' Logged from: Nikola Lukic'
    }

    # Write Keaton's logs to Jess
    if ($accountID -eq '5fc4f250facfd6007622abc8'){
        $accountID = '5d4c22d2cca0cf0c56be3666'
        $description += ' Logged from: Keaton Wiechman'
    }

    # Write Robin's logs to Jess
    if ($accountID -eq '5d5164bf4f89c40d98d68246'){
        $accountID = '5d4c22d2cca0cf0c56be3666'
        $description += ' Logged from: Robin Fuller'
    }

    # Write Robert's logs to Jess
    if ($accountID -eq '5d5d6c1bfaa9600c36097f70'){
        $accountID = '5d4c22d2cca0cf0c56be3666'
        $description += ' Logged from: Rober Mathews'
    }    

    $url = "https://api.tempo.io/core/3/worklogs"

    $Plaintoken = ConvertFrom-SecureString $token -AsPlainText

    $headers = @{
        'Authorization' = "Bearer $Plaintoken"
        'content-type' = "application/json"
    }

    $body = @{
        'issueKey' = $issueKey
        'timeSpentSeconds' = $time
        'startDate' = $startDate
        'startTime' = $startTime
        'description' = $description
        'authorAccountId' = $accountID
    } | ConvertTo-Json

    Try{
        $responce = Invoke-RestMethod -Method 'Post' -Uri $url -Headers $headers -Body $body
    }
    Catch{
        $ErrorString = $Error[0], $logID, $issueKey, $accountID
        Write-Host $ErrorString
        LogWrite $ErrorString
    }

    return $responce
    
}

$vmgaCred = Get-StoredCredential -Target 'TempoVMGA'
$prodCred = Get-StoredCredential -Target 'TempoProd'

$accessTokenVMGA = $vmgaCred.Password
$accessTokenforProd = $prodCred.Password

<# $worklogs = Get_Tempo_Worklogs -token $accessTokenVMGA -issueKey "PD-1594"
foreach ($log in $worklogs){
    $result = Add_Tempo_Worklog -logID $log.tempoWorklogId -token $accessTokenforProd -issueKey $log.issue.key -time $log.timeSpentSeconds -startDate $log.startDate -startTime $log.startTime  -description $log.description -accountID $log.author.accountID
} #>
#$worklogs

$issueKeys = Import-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\VMGA\finalworklogs.csv"

 foreach ($row in $issueKeys){
    Write-Host "Starting", $row.issueKey
    $worklogs = Get_Tempo_Worklogs -token $accessTokenVMGA -issueKey $row.issueKey
    
    foreach ($log in $worklogs){
        $result = Add_Tempo_Worklog -logID $log.tempoWorklogId -token $accessTokenforProd -issueKey $log.issue.key -time $log.timeSpentSeconds -startDate $log.startDate -startTime $log.startTime  -description $log.description -accountID $log.author.accountID
    }
}