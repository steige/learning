Import-Module -Name CredentialManager

$prodCred = Get-StoredCredential -Target 'TempoProd'
$Plaintoken = ConvertFrom-SecureString $prodCred.Password -AsPlainText
$tempoHeaders = @{
    'Authorization' = "Bearer $Plaintoken"
}

function Get-TempoTeamMembership {
    param (
        [Parameter(Mandatory=$true)]
        [string]$teamID,
        [Parameter(Mandatory=$true)]
        [string]$teamName
    )
    $returnObject = @()
 
    $url = "https://api.tempo.io/4/team-memberships/team/$teamID"

    Write-Host "Getting memberships for $teamName..."
    $responce = Invoke-RestMethod -Method Get -Uri $url -Headers $tempoHeaders

    foreach($membership in $responce.results){
        Write-Host "Getting user $($membership.member.accountId)..."
        
        $returnObject += [ordered]@{        
            'Team ID' = $teamID
            'Team Name' = $teamName
            'Member Email' = $membership.member.accountId
            'From' = if($membership.from){$membership.from}else{""}
            'To' = if($membership.to){$membership.to}else{""}
        }
    }

    return $returnObject
}

$csvOut = @()

$teams = Invoke-RestMethod -Method Get -Uri "https://api.tempo.io/4/teams?limit=100" -Headers $tempoHeaders

foreach($team in $teams.results){
    $csvOut += Get-TempoTeamMembership -teamID $team.id -teamName $team.name
}

$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\teamMembership.csv"