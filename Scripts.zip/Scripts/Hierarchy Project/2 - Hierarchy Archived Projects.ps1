Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}


function Unarchive-Project {
    param (
        [Parameter(Mandatory=$true)]
        [String]$projectKey
    )
        
    $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/project/$projectKey/restore"
    
    Invoke-RestMethod -Method 'Post' -Uri $url -Headers $headers
    
}

function Archive-Project {
    param (
        [Parameter(Mandatory=$true)]
        [String]$projectKey
    )
        
    $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/project/$projectKey/archive"
    
    Invoke-RestMethod -Method 'Post' -Uri $url -Headers $headers
    
}

<# $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/project/search?status=archived"
$projects = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
$issueArray = @()
    foreach ($project in $projects.values){
        $issueArray += @{
            "projectKey" = if($project.key){$project.key}else{""}
        }
        Unarchive-Project -projectKey $project.key
    }

$issueArray | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\archivedProject.csv" -Force #>

$projects = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\archivedProject.csv"
foreach ($project in $projects){
    Archive-Project -projectKey $project.projectKey
}
