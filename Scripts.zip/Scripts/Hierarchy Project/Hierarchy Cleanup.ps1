Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}
function Add-Parent {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey,
        [Parameter(Mandatory=$true)]
        [String]$parent
    )
    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?jql=parent=$parent and hierarchyLevel=0"
    $responce = -Method 'Get' -Uri $url -Headers $headers

    $newParent = $responce.issues[0].key

    $body = @{
        "fields" = @{
            "parent" = $newParent
        }
    } | ConvertTo-Json

    Invoke-RestMethod -Method 'Put' -Uri $url -Headers $headers -Body $body
    
    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue/$issueKey"

    $body = @{
        "fields" = @{
            "parent" = $parent
        }
    } | ConvertTo-Json

    Invoke-RestMethod -Method 'Put' -Uri $url -Headers $headers -Body $body
}

$array = @()
$startAt = 0
do {
    
    $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?jql=hierarchyLevel=1 and type in(Defect,`"Indirect Time`", `"Support Request`", `"Technical Debt`")&fields=issuetype,parent,summary&startAt=$startAt&maxResults=100"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    foreach ($issue in $responce.issues){
        $array += @{
            "issueKey" = if($issue.key){$issue.key}else{""}
            "summary" = if($issue.fields.summary){$issue.fields.summary}else{""}
            "issueType" = if($issue.fields.issuetype.name){$issue.fields.issuetype.name}else{""}
            "parent" = if($issue.fields.parent.key){$issue.fields.parent.key}else{""}
        }
    }

    $startAt += $responce.maxResults

} while ($responce.total -gt $startAt)

$parentData = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\allIssuesWithInitiatives.csv"

foreach ($issue in $array){
    $oldParent = $parentData | Where-Object {$_.issueKey -eq $issue.key}


    Add-Parent -issueKey $issue.key -parent $oldParent.issueKey
}