Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}


function Get-Epics {
    $array = @()
    $startAt = 0
    
    do {
    
        $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?jql=type in(Epic)&fields=issuetype,parent,summary&startAt=$startAt&maxResults=100"
        $epics = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
        foreach ($issue in $epics.issues){
            $array += @{
                "issueKey" = if($issue.key){$issue.key}else{""}
                "summary" = if($issue.fields.summary){$issue.fields.summary}else{""}
                "issueType" = if($issue.fields.issuetype.name){$issue.fields.issuetype.name}else{""}
                "parent" = if($issue.fields.parent.key){$issue.fields.parent.key}else{""}
            }
    
        }
    
        $startAt += $epics.maxResults
        Write-Host $startAt
    
    } while ($epics.total -gt $startAt)
    return $array
}

$issueArray = @()
$startAt = 0
#$epics = Get-Epics
do {
    #non stories
    $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?jql=hierarchyLevel = `"0`" and parent IS NOT EMPTY&fields=issuetype,parent,summary&startAt=$startAt&maxResults=100"
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    foreach ($issue in $responce.issues){

        if ($issue.fields.parent.fields.issuetype.name -ne "Epic"){
            $issueArray += @{
                "issueKey" = if($issue.key){$issue.key}else{""}
                "summary" = if($issue.fields.summary){$issue.fields.summary}else{""}
                "issueType" = if($issue.fields.issuetype.name){$issue.fields.issuetype.name}else{""}
                "parent" = if($issue.fields.parent.key){$issue.fields.parent.key}else{""}
                "parentType" = if($issue.fields.parent.fields.issuetype.name){$issue.fields.parent.fields.issuetype.name}else{""}
            }
        }
    }

    $startAt += $responce.maxResults
    Write-Host $startAt
} while ($responce.total -gt $startAt)

$issueArray | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\troubleTypesLevel0.csv" -Force