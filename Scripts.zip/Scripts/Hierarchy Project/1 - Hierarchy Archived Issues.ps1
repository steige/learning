Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}


function Get-Issue {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey
    )
        
    $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue/$issueKey"+"?fields=parent,issuetype,summary"
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
    return $responce
}

$issues = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\archived_issues.csv"
$issueArray = @()
    foreach ($row in $issues){
        $issue = Get-Issue -issueKey $row.issueKey
        $issueArray += @{
            "issueKey" = if($issue.key){$issue.key}else{""}
            "summary" = if($issue.fields.summary){$issue.fields.summary}else{""}
            "issueType" = if($issue.fields.issuetype.name){$issue.fields.issuetype.name}else{""}
            "parent" = if($issue.fields.parent.key){$issue.fields.parent.key}else{""}
            "parentType" = if($issue.fields.parent.fields.issuetype.name){$issue.fields.parent.fields.issuetype.name}else{""}
        }
    }

$issueArray | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\archivedIssues.csv" -Force