Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

$issueArray = @()
$issueArrayNoParent = @()
$startAt = 0

do {
    # Defect, Indirect Time, Support Request, Technical Debt
    $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?jql=hierarchyLevel = 1 and type != Epic and parent IS NOT EMPTY&fields=issuetype,parent,summary,project&startAt=$startAt&maxResults=100"
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    foreach ($issue in $responce.issues){
        $issueArray += @{
            "issueID" = if($issue.id){$issue.id}else{""}
            "issueKey" = if($issue.key){$issue.key}else{""}
            "summary" = if($issue.fields.summary){$issue.fields.summary}else{""}
            "issueType" = if($issue.fields.issuetype.name){$issue.fields.issuetype.name}else{""}
            "parent" = if($issue.fields.parent.key){$issue.fields.parent.key}else{""}
            "parentType" = if($issue.fields.parent.fields.issuetype.name){$issue.fields.parent.fields.issuetype.name}else{""}
        }   
    }

    $startAt += $responce.maxResults
    Write-Host $startAt
} while ($responce.total -gt $startAt)

$issueArray | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\troubleTypes.csv" -Force