Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Create-BridgeTask {
    param (
        [Parameter(Mandatory=$true)]
        [String]$parent,
        [Parameter(Mandatory=$true)]
        [String]$summary,
        [Parameter(Mandatory=$true)]
        [String]$project
    )

    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue"

    $body = @{
        "fields" = @{
            "project" = @{
                "key" = "$project"
            }
            "reporter" = @{
                "id" = "625f09e9acc9050068811778"
            }    
            "issuetype" = @{
                "name" = "Bridge"
            }
            "parent" =@{
                "key" = $parent
            } 
            "summary" = $summary
        }
    } | ConvertTo-Json

    $responce = Invoke-RestMethod -Method Post -Uri $url -Headers $headers -Body $body

    return $responce
    
}

function Add-Parent {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey,
        [Parameter(Mandatory=$true)]
        [String]$parent
    )
        
    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue/$issueKey"

    $body = @{
        "fields" = @{
            "parent" = @{
                "key" = $parent
            }
        }
    } | ConvertTo-Json

    Invoke-RestMethod -Method 'Put' -Uri $url -Headers $headers -Body $body
}

$initiatives = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\Initiatives.csv"
$tasks = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\allIssuesWithInitiatives_old.csv"

foreach($initiative in $initiatives){
    $taskArray = $tasks | Where-Object {$_.parent -eq $initiative.parent}
    $bridge = Create-BridgeTask -parent $initiative.parent -summary "$($initiative.summary) - Bridge" -project $initiative.project

    foreach($task in $taskArray){
        Add-Parent -issueKey $task.issueKey -parent $bridge.key
    }
}