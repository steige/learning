Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}


function Get-BridgeTask {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey
    )
    
    $startAt = 0
    $issueArray = @()
    do {
        $url =  "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?startAt=$startAt&maxResults=100&jql=parent = $issueKey&fields=issuetype"
    
        $responce = Invoke-RestMethod -Method 'get' -Uri $url -Headers $headers

        $issueArray += $responce.issues
        $startAt += $responce.maxResults
    } while ($responce.total -gt ($startAt - $responce.maxResults))
    
    foreach ($issue in $issueArray){
        if ($issue.fields.issuetype.name -eq "Bridge"){
            return $issue.key
        }
    }
    
}

$initiatives = Import-Csv "C:\Users\Micah.Harley\AzureFunctions\JediMindTricks\Jedi Mind Tricks\projectMapping.csv"
$csvOut = @()
foreach ($row in $initiatives) {
    $bridgeIssue = Get-BridgeTask -issueKey $row.ParentLink
    $csvOut += @{
        "ProjectKey" = $row.ProjectKey
        "Team" = $row.Team
        "Product" = $row.Product
        "ParentLink" = $bridgeIssue
    }
}

$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\AzureFunctions\JediMindTricks\Jedi Mind Tricks\projectMappingSandbox.csv" -Force