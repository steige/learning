Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Null-Parent {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey
    )
    
    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue/$issueKey"

    $body = @{
        "fields" = @{
            "parent" = $null
        }
    } | ConvertTo-Json

    Invoke-RestMethod -Method 'Put' -Uri $url -Headers $headers -Body $body
}

$issues = Import-Csv 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\HierarchyChange\troubleTypesNoParent.csv'

foreach ($issue in $issues){
    Null-Parent -issueKey $issue.issueKey
}