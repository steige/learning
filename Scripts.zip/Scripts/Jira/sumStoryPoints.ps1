Import-Module -Name CredentialManager
function SumEpicPoints {
    param (
        [Parameter()]
        [ValidateNotNull()]
        [System.Management.Automation.PSCredential]
        [System.Management.Automation.Credential()]
        $Credential,
        [Parameter()]
        [String]$issueKey
    )
    
    $sum = 0

    $pw = ConvertFrom-SecureString $Credential.Password -AsPlainText
    $Text = "$($Credential.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/search?jql=parentEpic%3D$issueKey&fields=customfield_10026"

    $headers = @{
        'Authorization' = "Basic $Cred"
        'Accept' = "*/*"
    }

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers



    foreach ($issue in $responce.issues){
        $sum += $issue.fields.customfield_10026
    }
    
    $newURL = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue/$issueKey"
    $body = @{
        "fields" = @{
            "customfield_10026" = $sum
        }
    } | ConvertTo-Json

    $headers += @{
        'Content-Type' = "application/json"
    }
    
    Invoke-RestMethod -Method 'Put' -Uri $newURL -Headers $headers -Body $body    
}

$cred = Get-StoredCredential -Target 'Atlassian'
SumEpicPoints -Credential $cred -issueKey 'PDPDE-4789'
