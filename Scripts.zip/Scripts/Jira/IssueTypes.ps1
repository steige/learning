Import-Module -Name CredentialManager

function DeleteIssueType {
    param (
        [Parameter()]
        [String]$IssueTypeID,
        [Parameter()]
        [String]$cred
    )

    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issuetype/$IssueTypeID"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = "*/*"
    }

    $responce = Invoke-RestMethod -Method 'Delete' -Uri $url -Headers $headers
}



$cred = Get-StoredCredential -Target 'Atlassian'

$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issuetype"

$headers = @{
    'Authorization' = "Basic $cred"
    'Accept' = "*/*"
}

$responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

foreach($issueType in $responce){
    if ($issueType.name -like "SM-*"){
        Write-Host $issueType.name, $issueType.id
        DeleteIssueType -IssueTypeID $issueType.id -cred $cred
    }
}