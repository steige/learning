Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-AllFilters {
    param (
        [Parameter(Mandatory=$true)]
        [String]$DepartedUserID
    )

    $url = "https://insurity.atlassian.net/rest/api/3/filter/search?accountId=$DepartedUserID"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    return $responce.values
    
}

function Set-FilterOwner {
    param (
        [Parameter(Mandatory=$true)]
        [String]$NewUserID,
        [Parameter(Mandatory=$true)]
        [String]$FilterID
    )

    $url = "https://insurity.atlassian.net/rest/api/3/filter/$FilterID/owner"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Content-Type' = 'application/json'
    }

    $body = @{
        "accountId" = $NewUserID
    } | ConvertTo-Json

    Invoke-RestMethod -Method 'Put' -Uri $url -Headers $headers -Body $body
    
}

$oldUser = '615750e099b4b8006a77f6e3'
$newUser = '6046416d58aa8d0072fa9509'

$filters = Get-AllFilters -DepartedUserID $oldUser

foreach ($filter in $filters){
    Set-FilterOwner -FilterID $filter.id -NewUserID $newUser
}