Import-Module -Name CredentialManager
$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Get-FeildValues {
    param (
        [Parameter(Mandatory=$true)]
        [String]$field,
        [Parameter(Mandatory=$true)]
        [String]$context
    )
    $returnList = @()

    $url =  "https://insurity.atlassian.net/rest/api/3/field/$field/context/$context/option"
    
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    
    foreach ($value in $responce.values){
        $returnList += @{
            "value" = $value.value
            "id" = $value.id
        }
    }
    
    return $returnList
}

$product = Get-FeildValues -field "customfield_10033" -context "10133"
# $products = Get-FeildValues -field "customfield_10084" -context "10192"
$csvOut = @()

#$control = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Sure Product Rename\products.csv"

foreach ($test in $product){
    #$tempProduct = $product | Where-Object {$_ -eq $test.JiraProductName}
    #$tempProducts = $products | Where-Object {$_ -eq $test.JiraProductName}
    $csvOut += @{
        "ID" = if($test.id){$test.id}else {""}
        "Value" = if($test.value){$test.value}else {""}
    }
} #>

$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Sure Product Rename\VerifiedProducts.csv" -Force 