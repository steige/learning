Import-Module -Name CredentialManager
function Get-FieldValueID {
    param (
        [Parameter(Mandatory=$true)]
        [String]$fieldID,
        [Parameter(Mandatory=$true)]
        [string]$context,
        [Parameter(Mandatory=$true)]
        [string]$valueName
    )

    $cred = Get-StoredCredential -Target 'Atlassian'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $startAt = 0

    do {
        $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/field/$fieldID/context/$context/option?startAt=$startAt"
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        $startAt += $responce.maxResults

        foreach ($value in $responce.values){
            if ($value.value -eq $valueName){
                return $value.id
            }
        }

    } while (-Not $responce.isLast)
    
    return 'Value not found'
}
function Remove-FieldValue {
    param (
        [Parameter(Mandatory=$true)]
        [String]$fieldID,
        [Parameter(Mandatory=$true)]
        [string]$contextID,
        [Parameter(Mandatory=$true)]
        [string]$valueName
    )
    
    $valueID = Get-FieldValueID -fieldID $fieldID -context $contextID -valueName $valueName

    if ($valueID -eq "Value not found"){
        return "Value not found"
    }

    $cred = Get-StoredCredential -Target 'Atlassian'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/field/$fieldID/context/$contextID/option/$valueID"

    try {
        Invoke-RestMethod -Method Delete -Headers $headers -Uri $url
        return 'Deleted Successfully'
    }
    catch {
        return 'Something went wrong'
    }

}
function Add-FieldValue {
    param (
        [Parameter(Mandatory=$true)]
        [String]$fieldID,
        [Parameter(Mandatory=$true)]
        [string]$context,
        [Parameter(Mandatory=$true)]
        [string]$valueName
    )

    $cred = Get-StoredCredential -Target 'Atlassian'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
        'Content-Type' = 'application/json'
    }

    $url = "https://insurity.atlassian.net/rest/api/3/field/$fieldID/context/$context/option"

    $body =  @{
        'options' = @(@{
            'disabled'= 'false'
            'value'= $valueName
    })
    } | ConvertTo-Json
    try {
        $responce = Invoke-RestMethod -Method Post -Headers $headers -Uri $url -Body $body
    }
    catch {
        return 'Value already Exists'
    }
    
    return $responce
}

$fieldID = "customfield_10055"
$context = "10158"

$customers = Import-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\impacted_customers.csv"

foreach ($customer in $customers){
    $Add = Add-FieldValue -fieldID $fieldID -context $context -valueName $customer.name
    $Add
}

<# $testAdd = Add-FieldValue -fieldID $fieldID -context $context -valueName $valueName
$testAdd

$Test = Remove-FieldValue -fieldID $fieldID -context $context -value $valueName
$Test #>