Import-Module -Name CredentialManager
function Get-IssueHistory {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueKey
    )
    
    $cred = Get-StoredCredential -Target 'Atlassian'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $url = "https://insurity.atlassian.net/rest/api/3/issue/$issueKey"+"?expand=changelog"

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

    foreach ($item in $responce.changelog.histories){
        if ($item.items[0].field -eq "Billable"){
            $item.items[0].fromSting + ", " + $item.items[0].toString + ", on: " + $item.created
        }
    }
    
    return $responce
}

Get-IssueHistory -issueKey "XAVIER-2104"