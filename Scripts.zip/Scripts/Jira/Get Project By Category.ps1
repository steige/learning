Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Get-ProjectByCategory {
    param (
        [Parameter(Mandatory=$true)]
        [String]$categoryId
    )

    $startAt = 0
    $returnArray = @()

    do {
        $url = "https://insurity.atlassian.net/rest/api/3/project/search?categoryId=$categoryId&startAt=$startAt"
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        $returnArray += $responce.values
        $startAt += $responce.maxResults
    } while ($responce.isLast -eq $false)

    return $returnArray
}

$categoryIds = @("10017", "10005", "10016")
$projects = @()

foreach ($categoryId in $categoryIds) {
    $projects += Get-ProjectByCategory -categoryId $categoryId   
}

$projects | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Projects.csv" -Force
