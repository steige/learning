
$headers = @{
    'api-token' = "aeea1f33835e83874ca72ad5816d79f66a2c502cafb235fe0041e48e50b9fe27"
    'Content-Type' = "application/json"
}
$url = "https://apim.workato.com/jamies384/jira-field-sync-collection-v1/jira/fields"

#for one
$body = @{
    "Jira_Field"= "Product"
    "New_Name"= "Sure Claims"
    "Current_Name" = "Insurity Claims"
    "Env" = "Prod"
} | ConvertTo-Json

$responce = Invoke-RestMethod -Uri $url -Method "POST" -Headers $headers -Body $body 
$responce

#For Multiple
<#
$productList = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Product Rename\Products.csv"
foreach($product in $productList){
    $body = @{
        "Jira_Field"= "Product"
        "New_Name"= $product.NewProductName
        "Current_Name" = $product.JiraCurrentName
        "Env" = "Prod"
    } | ConvertTo-Json

    $responce = Invoke-RestMethod -Uri $url -Method "POST" -Headers $headers -Body $body 
    $responce
} #>