Import-Module -Name CredentialManager

function Update-ProjectCategory {
    param (
        [Parameter(Mandatory=$true)]
        [String]$key,
        [Parameter(Mandatory=$true)]
        [String]$category,
        [Parameter(Mandatory=$true)]
        [String]$cred
    )
    
    $url = "https://insurity.atlassian.net/rest/api/3/project/$key"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
        'content-type' = 'application/json'
    }

    $body = @{
        "categoryId" = $category
    } | ConvertTo-Json

    $responce = Invoke-RestMethod -Method 'put' -Uri $url -Headers $headers -Body $body

}

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$path = 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\projectlist.csv'
$projects = Import-Csv -Path $path

foreach ($project in $projects){
    Update-ProjectCategory -key $project.key -category $project.categoryId -cred $cred
}

#Update-ProjectCategory -key "ENTARCH" -category "10004" -cred $cred