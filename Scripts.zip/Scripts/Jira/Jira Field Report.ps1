Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$csvOut = @()
$url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/field"
    
$headers = @{
    'Authorization' = "Basic $cred"
    'Accept' = '*/*'
}

try {
    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
}
catch {
    Write-Host "Bad Request"
}

foreach ($field in $responce){
    $csvOut += [ordered]@{
        "id" = if($field.id){$field.id}else {""}
        "name" = if($field.name){$field.name}else {""}
        "type" = if($field.schema.type){$field.schema.type}else {""}
        "custom?" = if($field.custom){$field.custom}else {"FALSE"}
        "customSchema" = if($field.schema.custom){$field.schema.custom}else {""}
        "arrayType" = if($field.schema.items){$field.schema.items}else {""}
        "isMulti?" = if($field.schema.configuration.isMulti){$field.schema.configuration.isMulti}else {"FALSE"}
        "OneProject?" = if($field.scope.project.id){$field.scope.project.id}else {""}
    }
}



$csvOut | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Scripts\fields.csv" -Force 