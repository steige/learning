Import-Module -Name CredentialManager
$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-FieldValueID {
    param (
        [Parameter(Mandatory=$true)]
        [String]$fieldID,
        [Parameter(Mandatory=$true)]
        [string]$context
    )

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $startAt = 0
    $returnArray = @()
    do {
        $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/field/$fieldID/context/$context/option?startAt=$startAt"
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        $startAt += $responce.maxResults

        foreach ($value in $responce.values){
            $returnArray += @{
                "valueID" = $value.id
                "valueName" = $value.value
                "isDisabled" = $value.disabled
            }
        }

    } while (-Not $responce.isLast)
    
    return $returnArray
}
function Remove-FieldValue {
    param (
        [Parameter(Mandatory=$true)]
        [String]$fieldID,
        [Parameter(Mandatory=$true)]
        [string]$contextID,
        [Parameter(Mandatory=$true)]
        [string]$valueName
    )
    
    $valueID = Get-FieldValueID -fieldID $fieldID -context $contextID -valueName $valueName

    if ($valueID -eq "Value not found"){
        return "Value not found"
    }

    $cred = Get-StoredCredential -Target 'Atlassian'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/field/$fieldID/context/$contextID/option/$valueID"

    try {
        Invoke-RestMethod -Method Delete -Headers $headers -Uri $url
        return 'Deleted Successfully'
    }
    catch {
        return 'Something went wrong'
    }

}
function Add-FieldValue {
    param (
        [Parameter(Mandatory=$true)]
        [String]$fieldID,
        [Parameter(Mandatory=$true)]
        [string]$context,
        [Parameter(Mandatory=$true)]
        [string]$valueName
    )

    $cred = Get-StoredCredential -Target 'Atlassian'
    $pw = ConvertFrom-SecureString $cred.Password -AsPlainText
    $Text = "$($cred.UserName):$pw"
    $Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $cred =[Convert]::ToBase64String($Bytes)

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
        'Content-Type' = 'application/json'
    }

    $url = "https://insurity.atlassian.net/rest/api/3/field/$fieldID/context/$context/option"

    $body =  @{
        'options' = @(@{
            'disabled'= 'false'
            'value'= $valueName
    })
    } | ConvertTo-Json
    try {
        $responce = Invoke-RestMethod -Method Post -Headers $headers -Uri $url -Body $body
    }
    catch {
        return 'Value already Exists'
    }
    
    return $responce
}

#Impacted Customer
#$fieldID = "customfield_10147"
#$context = "10271"

#Initiated by Customer
#$fieldID = "customfield_10055"
#$context = "10158"

#Product
#$fieldID = "customfield_10033"
#$context = "10133"

#Product(s)
$fieldID = "customfield_10084"
$context = "10192"

$customers = Get-FieldValueID -fieldID $fieldID -context $context

$customers | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Product(s).csv" -Force