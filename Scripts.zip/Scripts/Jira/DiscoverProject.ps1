Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-JiraPermistProjects {
    param (
    )
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'content-type' = 'application/json'
    }

    $body = @{
        "permissions" =@(
            "BROWSE_PROJECTS"
        )
    } | ConvertTo-Json

    $url = "https://insurity.atlassian.net/rest/api/3/permissions/project"

    $responce = Invoke-RestMethod -Method Post -Headers $headers -Uri $url -Body $body

    $returnArray = @()
    foreach ($project in $responce.projects){
        $returnArray += $project.key
    } 

    return $returnArray
}

function Get-JiraProjects {
    param (
    )
    
    $headers = @{
        'Authorization' = "Basic $cred"
    }

    $url = "https://insurity.atlassian.net/rest/api/3/project/search"
    $returnArray = @()

    do {
        
        $responce = Invoke-RestMethod -Method Get -Headers $headers -Uri $url
        
        foreach ($project in $responce.values){
            $returnArray += $project.key
        }

        $url = $responce.nextPage

    } while (-not ($responce.isLast))

    return $returnArray
}

$permProject = Get-JiraPermistProjects
$project = Get-JiraProjects


$delta = $project | where {$permProject -notcontains $_}
$delta

#$Yellow = $a | Where {$b -NotContains $_}