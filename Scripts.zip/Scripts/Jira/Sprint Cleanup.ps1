Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Get-BoardSprints {
    param (
        [Parameter(Mandatory=$true)]
        [String]$boardID
    )

    $startAt = 0
    $badSprintIDs = @()
    
    do {
        $url = "https://insurity.atlassian.net/rest/agile/1.0/board/$boardID/sprint?startAt=$startAt"

        $responce = Invoke-RestMethod -Method 'GET' -Uri $url -Headers $headers

        foreach ($sprint in $responce.values){
            if ($sprint.state -eq "future" -and $sprint.name -like "*... - Sprint *") {
                $badSprintIDs += @{
                    "id" = $sprint.id
                    "name" = $sprint.name
                }
            }
        }
        
        $startAt += $responce.maxResults

    } while (-not $responce.isLast)
        
    return $badSprintIDs
}

function Delete-Sprint {
    param (
        [Parameter(Mandatory=$true)]
        [String]$sprintID
    )
    
    $url = "https://insurity.atlassian.net/rest/agile/1.0/sprint/$sprintID"

    Invoke-RestMethod -Method 'DEL' -Uri $url -Headers $headers
}

#Board to be fix
$boardID = "336"
$sprints = Get-BoardSprints -boardID $boardID

foreach ($sprint in $sprints){
    Delete-Sprint -sprintID $sprint.id
}
