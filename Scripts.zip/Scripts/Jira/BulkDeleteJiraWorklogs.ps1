Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
}

function Convert-ToUNIXTime {
    param (
        [Parameter(Mandatory=$true)]
        [string]$date
    )
    return [int64](Get-Date -Date $date -UFormat %s)*1000
}
function Trim-JiraWorklogs {
    param (
        [Parameter(Mandatory=$true)]
        [string]$issueKey,
        [Parameter(Mandatory=$true)]
        [string]$beforeDate
    )
    
    $before = Convert-ToUNIXTime -date $beforeDate
    $startAt = 0

    do {
        $array = @()
        $url = "https://insurity.atlassian.net/rest/api/3/issue/$issueKey/worklog?startedBefore=$before&maxResults=1000"

        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

        foreach ($worklog in $responce.worklogs){
            $array += $worklog.id
        }
    
        $startAt += $responce.maxResults

        $worklogs = @{
            "ids" = $array
        } | ConvertTo-Json

        Delete-JiraWorklogs -issueKey $issueKey -worklogs $worklogs
        Write-Host "Deleted $startAt worklogs..."
    
    } while ($responce.total -gt 0)

}

function Delete-JiraWorklogs {
    param (
        [Parameter(Mandatory=$true)]
        [string]$issueKey,
        [Parameter(Mandatory=$true)]
        [string]$worklogs
    )
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'content-type' = "application/json"
    }

    $url = "https://insurity.atlassian.net/rest/api/3/issue/$issueKey/worklog?adjustEstimate=leave"

    Invoke-RestMethod -Method 'Delete' -Uri $url -Headers $headers -Body $worklogs
}

function Calculate-Date {
    param (
        [Parameter(Mandatory=$true)]
        [string]$issueKey
    )
    $monthsAgo = 0

    do {
        $monthsAgo --
        $date = (Get-Date).AddMonths($monthsAgo)
        $afterDate = Convert-ToUNIXTime -date $date
        $url = "https://insurity.atlassian.net/rest/api/3/issue/$issueKey/worklog?maxResults=1&startedAfter=$afterDate"
        $responce = Invoke-RestMethod -Method 'get' -Uri $url -Headers $headers
    } while ($responce.total -le 6000)
    
    return $date
}

$issueKey = 'TIME-9'

$beforeDate = Calculate-Date -issueKey $issueKey 
Trim-JiraWorklogs -issueKey $issueKey -beforeDate $beforeDate
