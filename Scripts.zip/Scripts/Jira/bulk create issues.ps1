Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Create-JiraIssue {
    param (
        [Parameter(Mandatory=$true)]
        [String]$issueType,
        [Parameter()]
        [String]$parentKey,
        [Parameter(Mandatory=$true)]
        [String]$projectKey,
        [Parameter(Mandatory=$true)]
        [String]$summary
    )

    $headers = @{
        'Authorization' = "Basic $cred"
        'content-type' = 'application/json'
    }
    
    $body = @{
        "fields" = @{        
            "issuetype" = @{
                "name" = "$issueType"
            }
            "labels" = @(
                "JediMindTricks"
            )
            "project" = @{
                "key" = "$projectKey"
            }
            "summary" = "$summary"
        }
    }
    
    if ($parentKey){
        $body.fields += @{
            "parent" = @{
                "key" = "$parentKey"
            }
        }
    }

    if ($issueType -eq "Epic"){
        $body.fields += @{
            "customfield_10011" = "$summary"
        }
    }

    if ($issueType -eq "Defect"){
        $body.fields += @{
            "customfield_10050" = @{
                "id" = "10077"
            }
        }
    }
    
    $body = $body | ConvertTo-Json
        
    $url = "https://insurity-sandbox-743.atlassian.net/rest/api/3/issue"
    
    Invoke-RestMethod -Method 'Post' -Uri $url -Headers $headers -Body $body
}

$issues = Import-Csv 'C:\Users\Micah.Harley\Documents\Scripts\Issues.csv'
foreach ($issue in $issues){
    Create-JiraIssue -issueType $issue.IssueType -projectKey $issue.Project -summary $issue.Summary
}
