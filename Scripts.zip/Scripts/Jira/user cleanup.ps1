Import-Module -Name CredentialManager

$Orgcred = Get-StoredCredential -Target 'InsurityOrg'
$token = ConvertFrom-SecureString $Orgcred.Password -AsPlainText

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Deactivate-User {
    param (
        [Parameter(Mandatory=$true)]
        [String]$userID
    )
    
    $headers = @{
        'Authorization' = "Bearer $token"
        'Content-Type' = 'application/json'
    }

    $url = "https://api.atlassian.com/users/$userID/manage/lifecycle/disable"

    try {
        Invoke-RestMethod -Uri $url -Headers $headers -Method POST
        Write-Host "Success $userID"
    }
    catch {
        Write-Host "Failed $userID"
    }
    
}

function Remove-UserGroup {
    param (
        [Parameter(Mandatory=$true)]
        [String]$userID,
        [Parameter(Mandatory=$true)]
        [String]$groupName,
        [Parameter()]
        [String]$server
    )
    
    if ($server -eq "prod"){
        $base = "https://insurity.atlassian.net"
    }
    else {
        $base = "https://insurity-sandbox-743.atlassian.net"
    }

    $headers = @{
        'Authorization' = "Basic $cred"
    }

    $url = "$base/rest/api/3/group/user?groupname=$groupName&accountId=$userID"

    try {
        Invoke-RestMethod -Uri $url -Headers $headers -Method DELETE
        Write-Host "success removing $userID from $group in $server"
    }
    catch {
        Write-Host "failure removing $userID from $group in $server"
    }
    
}

function Get-UserGroups {
    param (
        [Parameter(Mandatory=$true)]
        [String]$userID,
        [Parameter()]
        [String]$server
    )

    if ($server -eq "prod"){
        $base = "https://insurity.atlassian.net"
    }
    else {
        $base = "https://insurity-sandbox-743.atlassian.net"
    }

    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = "application/json"
    }
    
    $url = "$base/rest/api/3/user/groups?accountId=$userID"

    $responce = Invoke-RestMethod -Method GET -Uri $url -Headers $headers
    return $responce
}

function Remove-License {
    param (
        [Parameter(Mandatory=$true)]
        [String]$userID,
        [Parameter(Mandatory=$true)]
        [String]$product,
        [Parameter()]
        [String]$server
    )

    $groupList = Get-UserGroups -userID $userID -server $server

    if ($product -eq 'jira'){
        $accessGroups = @("administrators","Customer Success","jira-project-administrators",
        "jira-software-users","Sikich VMGA","site-admins","sprint-managers","tempo-administrators")

        foreach ($group in $accessGroups){
            if ($groupList.name | Where-Object {$_ -eq $group}){
                Remove-UserGroup -userID $userID -groupName $group -server $server
            }
        }
    }

    if ($product -eq 'confluence'){
        $accessGroups = @("administrators","Atlassian Service Accounts","codeobjects","confluence-users"
        "Corporate IT Support Team","jira-project-administrators","site-admins","Workato Contractors")

        foreach ($group in $accessGroups){
            if ($groupList.name | Where-Object {$_ -eq $group}){
                Remove-UserGroup -userID $userID -groupName $group -server $server
            }
        }
    }
    
}

# Use this when the user is still employed and still needs to be a Portal Only Customer
<# Remove-License -userID "5e8f2fa81008ef0b7ef0d72f" -server 'prod' -product 'jira'
Remove-License -userID "5e8f2fa81008ef0b7ef0d72f" -server 'prod' -product 'confluence'
Remove-License -userID "5e8f2fa81008ef0b7ef0d72f" -server 'sandbox' -product 'jira'
Remove-License -userID "5e8f2fa81008ef0b7ef0d72f" -server 'sandbox' -product 'confluence' #>

# Use this when the user is no longer empoyeed and needs all licenses removed
#Deactivate-User -userID "602ebadb5f99cc00683223b9"

$users = Import-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\User Clean Up\Round Six - Confluence Haven't accessed in 12 months.csv"

# foreach ($user in $users){
#     Deactivate-User -userID $user.accountId
# }

foreach ($user in $users){
    Remove-License -userID $user.accountId -server 'prod' -product 'confluence'
    Remove-License -userID $user.accountId -server 'sandbox' -product 'confluence'
}