Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-AtlassianID {
    param (
        [Parameter(Mandatory=$true)]
        [String]$env,
        [Parameter(Mandatory=$true)]
        [String]$userID)

    if ($env -eq 'Prod'){$baseUrl = "https://insurity.atlassian.net"}else{$baseUrl = "https://insurity-sandbox-743.atlassian.net"}

    $url = "$baseUrl/rest/api/3/user/search?query=$userID"
    
    $headers = @{
        'Authorization' = "Basic $cred"
        'Accept' = '*/*'
    }

    $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
    if ($responce[1]){
        return 'Multiple'
    }
    return $responce[0].accountId
}
function Add-UserToGroup {
    param (
        [Parameter(Mandatory=$true)]
        [String]$env,
        [Parameter(Mandatory=$true)]
        [String]$userID,
        [Parameter(Mandatory=$true)]
        [String]$groupName)

    if ($env -eq 'Prod'){$baseUrl = "https://insurity.atlassian.net"}else{$baseUrl = "https://insurity-sandbox-743.atlassian.net"}

    $url = "$baseUrl/rest/api/3/group/user?groupname=$groupName"

    $headers = @{
        'Authorization' = "Basic $cred"
        'Content-Type' = 'application/json'
    }

    $body = @{
        "accountId" = $userID
    } | ConvertTo-Json

    try {
        Invoke-RestMethod -Method 'Post' -Uri $url -Headers $headers -Body $body
        return 'success'
    }
    catch {
        return "$userID failed"
    }
    
    
}
function Remove-UserFromGroup {
    param (
        [Parameter(Mandatory=$true)]
        [String]$env,
        [Parameter(Mandatory=$true)]
        [String]$userID,
        [Parameter(Mandatory=$true)]
        [String]$groupName)

    if ($env -eq 'Prod'){$baseUrl = "https://insurity.atlassian.net"}else{$baseUrl = "https://insurity-sandbox-743.atlassian.net"}

    $url = "$baseUrl/rest/api/3/group/user?groupname=$groupName&accountId=$userID"

    $headers = @{
        'Authorization' = "Basic $cred"
    }

    $responce = Invoke-RestMethod -Method 'DELETE' -Uri $url -Headers $headers

    return $responce
    
}

$users = Import-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Users to add to Confluence User Group.csv"
foreach ($user in $users){
    #$userID = Get-AtlassianID -userID $user.Email -env 'sandbox'
    $result = Add-UserToGroup -userID $user.'User id' -groupName 'confluence-users' -env 'Prod'
    #$result1 = Add-UserToGroup -userID $user.'User id' -groupName 'loom-users-insurity' -env 'Prod'
    "$result $($user.'User name')"
}


<# $users = Import-Csv -Path "C:\Users\Micah.Harley\Downloads\Users to Deactivate.csv"

foreach ($user in $users){
    Remove-UserFromGroup -userID $user.UserID -groupName 'confluence-users'
    "Removed $($user.'User name')"
} #>
