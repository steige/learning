Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

$export = @()

$url = "https://insurity.atlassian.net/rest/api/3/project"
    
$headers = @{
    'Authorization' = "Basic $cred"
    'Accept' = '*/*'
}

$responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

foreach ($project in $responce){
    $export += @{
        "Project Key" = $project.key
        "Project Name" = $project.name
        "Current Category" = $project.projectCategory.name
    }
}

$export.GetEnumerator() |
    Select-Object -Property "Project Key", "Project Name", "Current Category" | 
    Export-Csv -NoTypeInformation -Path 'C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\projectlist.csv'