Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)
$headers = @{
    'Authorization' = "Basic $cred"
    'Content-Type' = "application/json"
}

function Get-IssueJQL {
    param (
        [Parameter(Mandatory=$true)]
        [String]$jql
    )
    $startAt = 0
    $returnArray = @()
    do {
        $url = "https://insurity.atlassian.net/rest/api/3/search/jql?jql=$jql&fields=summary,customfield_10075,parent&startAt="+$startAt
        
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers

        foreach ($issue in $responce.issues){
            $returnArray += @{
                "key" = $issue.key
                "summary" = $issue.fields.summary
                "ProjectType" = if($issue.fields.customfield_10075){$issue.fields.customfield_10075}else {""}
                "parent" = if($issue.fields.parent.key){$issue.fields.parent.key}else{""}
            }
        }
        $startAt += $responce.maxResults
        Write-Host $startAt
    } while (
        $responce.total -ge $startAt
    )
    
    return $returnArray
}

$initiatives = Get-IssueJQL -jql "type = Initiative and project in(INSU, RCCLR) and `"Project System ID[Short text]`" IS NOT EMPTY"
$bridges = Get-IssueJQL -jql "type = Bridge and project in(INSU, RCCLR) and `"Project System ID[Short text]`" IS EMPTY"

$bridges | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\bridges to fix.csv" -Force
$initiatives | Export-Csv -Path "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Documents\Initiatives.csv" -Force