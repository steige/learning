Import-Module CredentialManager
Import-Module JiraPS

Set-JiraConfigServer "https://insurity.atlassian.net"

$cred = Get-StoredCredential -Target 'Atlassian'
New-JiraSession -Credential $cred

$test = Get-JiraIssue -Key "BM-999"
$test.Summary