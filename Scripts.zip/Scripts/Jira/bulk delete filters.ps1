Import-Module -Name CredentialManager

$cred = Get-StoredCredential -Target 'Atlassian'
$pw = ConvertFrom-SecureString $cred.Password -AsPlainText
$Text = "$($cred.UserName):$pw"
$Bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
$cred =[Convert]::ToBase64String($Bytes)

function Get-AllFilters {
    param ()

    $headers = @{
        'Authorization' = "Basic $cred"
    }

    $continue = $true
    $startAt = 0
    
    while ($continue) {
        $url = "https://insurity.atlassian.net/rest/api/3/filter/search?startAt=$startAt&maxResults=100"
        $responce = Invoke-RestMethod -Method 'Get' -Uri $url -Headers $headers
        $returnObject += $responce.values
        $startAt += $responce.maxResults

        if ($responce.isLast) {
            $continue = $false
        }
    }
    

    return $returnObject
}

function Delete-Filter {
    param (
        [Parameter(Mandatory=$true)]
        [String]$id
    )
    
    $headers = @{
        'Authorization' = "Basic $cred"
    }

    $url = "https://insurity.atlassian.net/rest/api/3/filter/$id"
    
    Invoke-RestMethod -Method 'Delete' -Uri $url -Headers $headers

}

$filters = Get-AllFilters

$toDelete = Import-Csv "C:\Users\Micah.Harley\OneDrive - Insurity, Inc\Filters to delete.csv"

foreach ($name in $toDelete){
    $filter = $filters | Where-Object {$_.name -EQ $name.name}

    if ($filter) {
        Delete-Filter -id $filter.id
    }
}

