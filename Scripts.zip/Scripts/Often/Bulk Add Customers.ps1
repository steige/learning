$url = "http://localhost:7071/api/orchestrators/AddCustomer"

$headers = @{
    "Content-Type" = "application/json"
}

$customers = Import-Csv -Path "C:\Users\Micah.Harley\Downloads\Customers.csv"

foreach($customer in $customers){
    $body = '{
        "server": "https://insurity.atlassian.net",
        "fieldValue": "' + $customer."Account Name" + '"
    }'

    Invoke-RestMethod -Method "Post" -Uri $url -Headers $headers -Body $body
}